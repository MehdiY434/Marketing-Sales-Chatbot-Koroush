# راه‌اندازی و اجرای واقعی

این بسته مستقل از مخزن برنامه کاربر است؛ آن را در پوشه مهارت نصب کن، نه در کد برنامه نامرتبط. Python 3.11 تا 3.13 مناسب است؛ ترکیب دقیق همراه در Python 3.12 آزمایش شده است. نیازهای سیستم: ImageMagick 7 با PSD/LCMS، Pillow با RAQM، فونت مجاز با پوشش متن و فایل CMYK ICC معتبر. فتوشاپ برای مسیر پایه لازم نیست؛ برای مسیر بومی/بدیل لازم است.

متغیر `SKILL_DIR` را به مسیر واقعی همین بسته و مسیر ICC/فونت را به فایل‌های موجود تغییر بده. از اینترنت بدون تأیید TLS، پروفایل نامعتبر یا فونت بی‌مجوز استفاده نکن. وابستگی‌های بومی را با package manager مورد اعتماد همان سیستم تهیه کن؛ نبود `magick` یا RAQM یک پیش‌نیاز حل‌نشده است.

```bash
SKILL_DIR=/absolute/path/to/cmyk-layered-photoshop
python3 -m venv /workspace/.venvs/cmyk-psd
/workspace/.venvs/cmyk-psd/bin/python -m pip install -r "$SKILL_DIR/requirements.txt"
/workspace/.venvs/cmyk-psd/bin/python "$SKILL_DIR/scripts/preflight.py" \
  --icc /path/to/real-cmyk.icc --font /path/to/approved-font.ttf \
  --width 2480 --height 3508 --layers 5 --max-working-mb 2048
```

preflight نمونه هندسی کوچک می‌سازد؛ هزینه تولید تصویر ندارد. نویسنده واقعی، alpha، متن شکل‌یافته فارسی/لاتین، TIFF/PNG، هر دو خواننده و موارد منفی را اجرا می‌کند. نمونه هندسی خروجی طراحی برای مشتری نیست. فایل موقت پاک می‌شود؛ اگر به مدرک ماندگار نیاز است smoke را در مسیر تازه اجرا کن:

```bash
/workspace/.venvs/cmyk-psd/bin/python "$SKILL_DIR/tests/smoke.py" /workspace/scratch/cmyk-check-new \
  --icc /path/to/real-cmyk.icc --font /path/to/approved-font.ttf
```

مسیر آزمایشی این محیط `/usr/share/color/icc/ghostscript/default_cmyk.icc` است: **Artifex CMYK SWOP Profile**. فقط برای smoke و فرض سازگار SWOP به‌کار رفت؛ انتخاب آن برای چاپ نهایی بدون بررسی شرایط توصیه نمی‌شود. فونت fixture موفق `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf` بود. هیچ ICC یا فونتی بدون بررسی اجازه توزیع در بسته کپی نشده است.

## تولید کار واقعی

۱. مشخصات، پلان لایه‌ها، متن و هدف چاپ را ثبت کن. preflight را اجرا کن. خروجی طراحی RGB مرجع را برای مقایسه بصری نگه دار.

۲. اجزا را با ابزار تولید تصویر بساز یا از ورودی استخراج/بازسازی کن. PNGهای RGBA، پس‌زمینه کامل، لوگوی اصل و منابع فونت را در پوشه پروژه تازه ذخیره کن. اسکریپت‌های این بسته ابزار ساخت تصویر مولد نیستند.

۳. متن را در فایل UTF-8 و فونت مجاز نگه دار؛ نمونه فرمان:

```bash
/workspace/.venvs/cmyk-psd/bin/python "$SKILL_DIR/scripts/render_text.py" \
  --text-file /path/to/project/headline.txt --font /path/to/approved-font.ttf \
  --size 160 --direction rtl --color '#162638' --output /path/to/project/assets/headline.png
```

این مسیر عمداً متن را پیکسلی می‌کند؛ shape فارسی و پوشش glyph بررسی و خروجی در لایه متن جدا مونتاژ می‌شود. اگر فونت فارسی glyph لاتین ندارد، به‌جای مربعی‌شدن خروجی خطا می‌دهد. برای ترکیب چند فونت، runها را جدا رندر و روی یک بوم متن ترکیب کن؛ خوانایی و bidi را دیداری تأیید کن. برای متن بومی قابل‌ویرایش از فتوشاپ/ابزار تأییدشده استفاده کن.

۴. `job.json` واقعی را مطابق manifest بنویس؛ مسیر `out-new` باید فاقد تحویل قبلی باشد:

```bash
/workspace/.venvs/cmyk-psd/bin/python "$SKILL_DIR/scripts/build.py" /path/to/project/job.json /path/to/project/out-new
/workspace/.venvs/cmyk-psd/bin/python "$SKILL_DIR/scripts/validate.py" /path/to/project/out-new
magick identify -format '%m|%[colorspace]|%w|%h\n' /path/to/project/out-new/artwork.psd
```

۵. گزارش `qa.json` و تصاویر `qa-renders` را بازبینی کن و چک‌لیست انسانی را با نتیجه واقعی تکمیل کن. psd-tools 1.12.1 در مسیر high-level `composite(force=True)` ممکن است برای CMYKA خطا بدهد؛ validator از **compositor چهاراناله سطح پایین** و مقایسه با `topil(apply_icc=False)` استفاده می‌کند. این مسیر واقعاً آزمایش شده است. خطای high-level را با حذف QA یا اعتماد صرف به cached preview دور نزن.

۶. بازخوانی یک بار در خود فتوشاپ اگر موجود است؛ در نبود آن محدودیت را بگو. PSD/CMYK TIFF/PNG sRGB را تحویل بده و PNG را «پیش‌نمایش RGB» بنام. build.json اطلاعات پروفایل، هش‌ها و محدودیت‌ها را دارد. وضعیت خودکار «technical checks passed» به معنی تأیید دیداری، تأیید چاپخانه یا آزمایش فتوشاپ نیست.

## بدیل فتوشاپ

برای محیطی که writer/خواننده قابل اتکا ندارد، پس از توضیح محدودیت یک بسته مستقل بساز: job.json، assets با مسیر نسبی، کپی دقیق متن و مشخصات فونت، لوگوی اصل، ICC در صورت داشتن اجازه توزیع، و اسکریپت:

```bash
python3 "$SKILL_DIR/scripts/photoshop_assembly.py" /path/to/project/job.json /path/to/project/assemble.jsx
```

اپراتور در Photoshop از `File > Scripts > Browse` فایل JSX را اجرا می‌کند. خروجی آن یک **سند پیش‌نویس RGB** با اجزای مستقل است و چیزی به نام PSD نهایی ذخیره نمی‌کند. JSX در این محیط فتوشاپ اجرا نشده است. ابتدا پروفایل واقعی دارایی‌های RGB را بررسی کن؛ این بدیل فرض می‌کند دارایی‌ها پیشاپیش در فضای RGB مشترک و مستند آماده شده‌اند. تبدیل‌های خودکار هنگام بازکردن فایل را کورکورانه تأیید نکن.

سپس در `Edit > Convert to Profile` پروفایل CMYK نصب‌شده چاپخانه را با نام صحیح انتخاب، گزینه flatten را غیرفعال و حفظ لایه‌ها را بررسی کن. در صورت نیاز متن را با Type tool و موتور حروف‌چینی مناسب فارسی دوباره به‌صورت بومی اضافه و لایه پیکسلی جایگزین را مخفی/حذف کن. `Image > Mode` باید CMYK باشد. با Save As/Save a Copy به PSD با Layers و Embed ICC ذخیره کن؛ TIFF تخت CMYK و PNG تبدیل‌شده به sRGB را جدا خروجی بگیر. بعد فایل‌های **ذخیره‌شده** را باز کن و چک‌لیست عمومی را اجرا کن. تولید JSX به‌تنهایی این مراحل را تأیید نمی‌کند.

## منابع فنی

- [Adobe Photoshop File Formats Specification](https://www.adobe.com/devnet-apps/photoshop/fileformatashtml/): header، Layer and Mask Information، کانال‌ها، ICC resource 1039، resolution resource 1005 و Unicode layer name.
- [Pillow ImageCms](https://pillow.readthedocs.io/en/stable/reference/ImageCms.html): تبدیل ICC و rendering intent.
- [psd-tools](https://psd-tools.readthedocs.io/en/latest/): خواننده و compositor مستقل؛ قابلیت نوشتن RGB این کتابخانه مدرک کافی برای CMYK نیست.
- [ImageMagick PSD](https://imagemagick.org/script/formats.php): خواننده دوم؛ فقط نصب بودن برنامه جای smoke واقعی را نمی‌گیرد.
