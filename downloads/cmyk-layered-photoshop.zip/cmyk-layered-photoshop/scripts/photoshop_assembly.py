#!/usr/bin/env python3
"""Generate a portable ExtendScript assembly fallback, NOT a completed CMYK file.

Copy a job.json plus its assets into a delivery directory; emit assemble.jsx
alongside it. Photoshop is not required to produce this script. It is required
to run it. Native text/CMYK conversion remain explicit operator steps.
"""
import argparse
import json
from pathlib import Path


def generate(manifest,output):
    path=Path(manifest).resolve()
    job=json.loads(path.read_text(encoding='utf-8'))
    output=Path(output).resolve()
    if output.parent != path.parent:
        raise ValueError('Place assemble.jsx next to job.json to preserve relative asset paths')
    if output.exists():
        raise FileExistsError(output)
    for layer in job['layers']:
        source=(path.parent/layer['file']).resolve()
        if not source.is_file() or not source.is_relative_to(path.parent):
            raise ValueError('Fallback assets must exist beneath the assembly directory')
        if layer.get('blend','normal')!='normal':
            raise ValueError('Fallback only supports normal blend')
    script=r'''#target photoshop
// RGB ASSEMBLY DRAFT ONLY. Inspect, convert to the specified CMYK profile,
// keep layers, embed ICC, save PSD + CMYK TIFF + sRGB PNG, and revalidate.
var job = __JOB__;
var root = File($.fileName).parent;
var oldUnits = app.preferences.rulerUnits;
var oldDialogs = app.displayDialogs;
app.preferences.rulerUnits = Units.PIXELS;
try {
  app.displayDialogs = DialogModes.ALL;
  var doc = app.documents.add(job.width,job.height,job.dpi,
    "RGB ASSEMBLY DRAFT - convert and validate",NewDocumentMode.RGB,DocumentFill.TRANSPARENT);
  var dummy = doc.activeLayer;
  for (var i=0;i<job.layers.length;i++) {
    var spec=job.layers[i];
    var src=app.open(new File(root.fsName+"/"+spec.file));
    if(src.mode != DocumentMode.RGB) throw new Error("Provide RGB/RGBA assets: "+spec.file);
    var left=src.activeLayer.bounds[0].as("px");
    var top=src.activeLayer.bounds[1].as("px");
    var layer=src.activeLayer.duplicate(doc,ElementPlacement.PLACEATBEGINNING);
    src.close(SaveOptions.DONOTSAVECHANGES);
    app.activeDocument=doc;
    layer.name=spec.name;
    layer.translate((spec.x||0)+left-layer.bounds[0].as("px"),
                    (spec.y||0)+top-layer.bounds[1].as("px"));
    layer.opacity=(spec.opacity===undefined?255:spec.opacity)*100/255;
    layer.blendMode=BlendMode.NORMAL;
  }
  dummy.remove();
  alert("Assembly draft only. Inspect layer order/edges/Persian text. Use Edit > Convert to Profile with the exact target CMYK ICC (not Assign Profile), retain layers, and embed ICC on Save As. Target profile file: "+job.icc+". No finished CMYK PSD has been saved by this script.");
} finally {
  app.preferences.rulerUnits=oldUnits;
  app.displayDialogs=oldDialogs;
}
'''
    output.write_text(script.replace('__JOB__',json.dumps(job,ensure_ascii=True)),encoding='utf-8')
    print('Created Photoshop assembly script; execution and CMYK conversion NOT tested here')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('manifest')
    p.add_argument('output')
    a=p.parse_args()
    generate(a.manifest,a.output)
