#!/usr/bin/env python3
"""Small, deliberately restricted PSD v1 writer: 8-bit CMYK normal pixel layers.

The independent validator is validate.py (psd-tools); no psd-tools writer is used.
PSD CMYK channel bytes are inverted, while TIFF/Pillow CMYK bytes are ink values.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path

import numpy as np
from PIL import Image, ImageCms, ImageOps


def pack(fmt, *values):
    return struct.pack('>' + fmt, *values)


def sized(data):
    if len(data) >= 2**32:
        raise ValueError('PSD section exceeds 32-bit size; use Photoshop/PSB workflow')
    return pack('I', len(data)) + data


def profile(path):
    data = Path(path).read_bytes()
    if len(data) < 128 or data[36:40] != b'acsp' or data[16:20] != b'CMYK':
        raise ValueError('A genuine CMYK ICC profile is required')
    p = ImageCms.ImageCmsProfile(str(path))
    return data, p


def resource(number, data):
    return b'8BIM' + pack('H', number) + b'\0\0' + sized(data) + b'\0' * (len(data) % 2)


def load_job(path):
    path = Path(path).resolve()
    job = json.loads(path.read_text(encoding='utf-8'))
    w, h = job['width'], job['height']
    if not all(type(v) is int and 1 <= v <= 30000 for v in (w, h)):
        raise ValueError('PSD v1 canvas dimensions must be 1..30000 pixels')
    # Deliberate memory ceiling for this non-streaming implementation.
    if w * h > job.get('max_pixels', 40_000_000):
        raise ValueError('Canvas exceeds memory budget; plan a tiled/Photoshop path before generation')
    estimate_mb = w*h*(64+12*len(job['layers']))/1024**2
    if estimate_mb > job.get('max_working_mb',1024):
        raise ValueError(f'Estimated peak {estimate_mb:.0f} MiB exceeds budget; plan resources first')
    if not 1 <= float(job['dpi']) <= 10000:
        raise ValueError('Invalid dpi')
    if not job.get('profile_reason'):
        raise ValueError('Document the printing condition/profile assumption in profile_reason')
    icc_path = (path.parent / job['icc']).resolve()
    icc, target = profile(icc_path)
    srgb = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'))
    layers, names, hashes = [], set(), set()
    if not 2 <= len(job['layers']) <= 1000:
        raise ValueError('Require 2..1000 meaningful layers, listed bottom to top')
    for spec in job['layers']:
        name = spec['name']
        if not name or name in names:
            raise ValueError('Layer names must be nonempty and unique')
        names.add(name)
        if not spec.get('role') or not spec.get('provenance'):
            raise ValueError('Each layer requires role and provenance')
        if spec.get('blend', 'normal') != 'normal':
            raise ValueError('Only normal blend is supported; do not silently flatten effects')
        source = (path.parent / spec['file']).resolve()
        with Image.open(source) as original:
            if original.mode not in ('RGB', 'RGBA'):
                raise ValueError(f'{name}: provide RGB/RGBA source; no silent profile reassignment')
            embedded = original.info.get('icc_profile')
            image = ImageOps.exif_transpose(original).convert('RGBA')
        if not embedded and not job.get('assume_untagged_srgb', False):
            raise ValueError(f'{name}: untagged input; explicitly declare the sRGB assumption')
        import io
        source_profile = ImageCms.ImageCmsProfile(io.BytesIO(embedded)) if embedded else srgb
        if source_profile.profile.xcolor_space.strip() != 'RGB':
            raise ValueError(f'{name}: input profile is not RGB')
        alpha = np.array(image.getchannel('A'))
        if not alpha.any():
            raise ValueError(f'{name}: empty layer')
        digest = hashlib.sha256(image.tobytes()).hexdigest()
        if digest in hashes:
            raise ValueError('Duplicate pixel layers are not meaningful independent components')
        hashes.add(digest)
        x, y = spec.get('x', 0), spec.get('y', 0)
        if not all(type(v) is int for v in (x, y)) or x < 0 or y < 0 or x+image.width > w or y+image.height > h:
            raise ValueError(f'{name}: raster bounds must be inside the canvas')
        opacity = spec.get('opacity', 255)
        if type(opacity) is not int or not 1 <= opacity <= 255:
            raise ValueError('Opacity must be 1..255')
        converted = ImageCms.profileToProfile(image.convert('RGB'), source_profile, target,
            outputMode='CMYK', renderingIntent=ImageCms.Intent.RELATIVE_COLORIMETRIC,
            flags=ImageCms.Flags.BLACKPOINTCOMPENSATION)
        layers.append(dict(name=name, x=x, y=y, width=image.width, height=image.height,
            opacity=opacity, color=np.array(converted), alpha=alpha, spec=spec))
    base = layers[0]
    if base['spec']['role'] != 'background' or (base['x'],base['y'],base['width'],base['height']) != (0,0,w,h) or base['opacity'] != 255 or not np.all(base['alpha'] == 255):
        raise ValueError('Bottom layer must be a complete opaque background covering the canvas')
    return job, layers, icc, target, srgb


def composite(layers, w, h):
    ink = np.zeros((h,w,4), dtype=np.float32)  # Paper white.
    for layer in layers:
        x,y = layer['x'],layer['y']
        a = layer['alpha'][...,None].astype(np.float32)/255 * layer['opacity']/255
        region = ink[y:y+layer['height'],x:x+layer['width']]
        region[:] = layer['color']*a + region*(1-a)
    return np.clip(np.rint(ink), 0, 255).astype('uint8')


def write_psd(path, job, layers, icc, merged):
    records, pixels = [], []
    # PSD records and psd-tools API are bottom to top (verified by forced recomposition).
    for l in layers:
        planes = [(-1,l['alpha'])] + [(i,255-l['color'][...,i]) for i in range(4)]
        channels = [(i,b'\0\0'+plane.tobytes()) for i,plane in planes]
        fallback = l['name'].encode('ascii','replace')[:255]
        pascal = bytes([len(fallback)])+fallback
        pascal += b'\0' * (-len(pascal) % 4)
        utf16 = l['name'].encode('utf-16be')
        unicode_name = pack('I',len(utf16)//2)+utf16
        extra = b'\0'*8 + pascal + b'8BIMluni' + sized(unicode_name) + b'\0'*(len(unicode_name)%2)
        record = pack('iiiiH',l['y'],l['x'],l['y']+l['height'],l['x']+l['width'],len(channels))
        record += b''.join(pack('hI',i,len(data)) for i,data in channels)
        record += b'8BIMnorm' + pack('BBBB',l['opacity'],0,0,0) + sized(extra)
        records.append(record)
        pixels.extend(data for _,data in channels)
    info = pack('h',len(layers))+b''.join(records)+b''.join(pixels)
    info += b'\0'*(len(info)%2)
    layer_mask = sized(info)+b'\0'*4
    dpi = round(job['dpi']*65536)
    resources = resource(1039,icc)+resource(1005,pack('IHHIHH',dpi,1,1,dpi,1,1))
    header = b'8BPS'+pack('H',1)+b'\0'*6+pack('HIIHH',4,job['height'],job['width'],8,4)
    merged_bytes = b'\0\0'+b''.join((255-merged[...,i]).tobytes() for i in range(4))
    data = header+b'\0'*4+sized(resources)+sized(layer_mask)+merged_bytes
    if len(data) >= 2_000_000_000:
        raise ValueError('PSD exceeds supported size; use PSB via Photoshop instead')
    Path(path).write_bytes(data)


def build(manifest, output):
    job,layers,icc,target,srgb = load_job(manifest)
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    # Never overwrite previous deliverables inadvertently.
    for name in ('artwork.psd','artwork-cmyk.tif','preview-rgb.png','build.json'):
        if (output/name).exists():
            raise FileExistsError(output/name)
    merged = composite(layers,job['width'],job['height'])
    write_psd(output/'artwork.psd',job,layers,icc,merged)
    flattened = Image.fromarray(merged,'CMYK')
    flattened.save(output/'artwork-cmyk.tif',compression='tiff_lzw',icc_profile=icc,dpi=(job['dpi'],)*2)
    preview = ImageCms.profileToProfile(flattened,target,srgb,outputMode='RGB',
        renderingIntent=ImageCms.Intent.RELATIVE_COLORIMETRIC,flags=ImageCms.Flags.BLACKPOINTCOMPENSATION)
    preview.save(output/'preview-rgb.png',icc_profile=srgb.tobytes(),dpi=(job['dpi'],)*2)
    report = dict(status='built_not_yet_validated',width=job['width'],height=job['height'],dpi=job['dpi'],
        profile=ImageCms.getProfileDescription(target).strip(),profile_sha256=hashlib.sha256(icc).hexdigest(),
        profile_reason=job['profile_reason'],bleed_mm=job.get('bleed_mm'),
        text_editability='Raster only; no native Photoshop text layers',photoshop_tested=False,
        assumptions=['untagged RGB assigned sRGB'] if job.get('assume_untagged_srgb') else [],
        limits=['8-bit CMYK pixel layers','normal blend only','no native masks/groups/Smart Objects/effects',
                'technical checks do not certify print-shop approval or visual quality'],
        layers=[{k:v for k,v in l.items() if k not in ('color','alpha')} for l in layers],
        files={n:hashlib.sha256((output/n).read_bytes()).hexdigest() for n in ('artwork.psd','artwork-cmyk.tif','preview-rgb.png')})
    (output/'build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('status','profile','width','height')},ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('manifest')
    parser.add_argument('output')
    args = parser.parse_args()
    build(args.manifest,args.output)
