#!/usr/bin/env python3
"""Render exact raster text with real RTL shaping, never pretend it is native type."""
import argparse
import unicodedata
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,features
from fontTools.ttLib import TTFont


def render(text,font,size,output,direction='rtl',color='#151515'):
    if not features.check_feature('raqm'):
        raise RuntimeError('Pillow with libraqm/HarfBuzz/FriBidi is required for RTL shaping')
    with TTFont(str(font)) as face:
        cmap=face.getBestCmap()
        missing=sorted({c for c in text if not unicodedata.category(c).startswith('C') and ord(c) not in cmap})
    if missing:
        raise ValueError('Font lacks glyphs: '+repr(''.join(missing))+'; choose an approved font or split into font runs')
    font=ImageFont.truetype(str(font),size,layout_engine=ImageFont.Layout.RAQM)
    options=dict(font=font,direction=direction,language='fa' if direction=='rtl' else 'en')
    box=ImageDraw.Draw(Image.new('RGBA',(1,1))).multiline_textbbox((0,0),text,**options)
    image=Image.new('RGBA',(max(1,box[2]-box[0])+16,max(1,box[3]-box[1])+16))
    ImageDraw.Draw(image).multiline_text((8-box[0],8-box[1]),text,fill=color,**options)
    if Path(output).exists():
        raise FileExistsError(output)
    image.save(output)
    return image


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--text-file',required=True,help='UTF-8 exact approved copy; no manual reversal')
    p.add_argument('--font',required=True)
    p.add_argument('--size',type=int,required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--direction',choices=['rtl','ltr'],default='rtl')
    p.add_argument('--color',default='#151515')
    a=p.parse_args()
    render(Path(a.text_file).read_text(encoding='utf-8'),a.font,a.size,a.output,a.direction,a.color)
