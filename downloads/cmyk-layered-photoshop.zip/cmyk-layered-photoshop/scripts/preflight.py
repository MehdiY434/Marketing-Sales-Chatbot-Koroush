#!/usr/bin/env python3
"""Run BEFORE costly image generation; exercise the real writer and two readers."""
import argparse
import importlib.metadata
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tests'))
from smoke import main as smoke
from build import profile


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--icc',required=True)
    p.add_argument('--font',required=True)
    p.add_argument('--width',type=int,required=True)
    p.add_argument('--height',type=int,required=True)
    p.add_argument('--layers',type=int,required=True)
    p.add_argument('--max-working-mb',type=int,default=1024)
    a=p.parse_args()
    if not (1<=a.width<=30000 and 1<=a.height<=30000 and 2<=a.layers<=1000):
        raise ValueError('Unsupported PSD v1 dimensions/layer count')
    estimate=a.width*a.height*(64+12*a.layers)/1024**2
    if a.width*a.height>40_000_000 or estimate>a.max_working_mb:
        raise ValueError(f'Budget exceeded: estimated {estimate:.0f} MiB. Replan before generating images.')
    if not shutil.which('magick'):
        raise RuntimeError('ImageMagick 7 with PSD/ICC support is required for the second reader smoke check')
    profile(a.icc)
    for dependency in ('Pillow','numpy','psd-tools','attrs','fonttools'):
        print(dependency,importlib.metadata.version(dependency))
    print(f'Conservative working-memory estimate: {estimate:.0f} MiB; use one job at a time')
    with tempfile.TemporaryDirectory(prefix='cmyk-preflight-') as temp:
        smoke(Path(temp)/'fixture',a.icc,a.font)
    print('PREFLIGHT PASSED: baseline pixel-layer path only; no Photoshop/native type claim')
