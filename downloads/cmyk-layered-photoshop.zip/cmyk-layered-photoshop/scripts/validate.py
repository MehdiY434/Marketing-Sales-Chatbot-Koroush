#!/usr/bin/env python3
"""Fail closed technical QA, independently decoded by psd-tools.

Visual/source integrity, glyph correctness, and Photoshop acceptance are separate
human checks. This script never reports those as passed.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageCms
from psd_tools import PSDImage
from psd_tools.composite import composite as independent_composite
from psd_tools.constants import ColorMode, Resource


def require(condition, message):
    if not condition:
        raise ValueError(message)


def maxdiff(a,b):
    require(a.shape == b.shape, f'Shape mismatch: {a.shape} != {b.shape}')
    return int(np.max(np.abs(a.astype('int16')-b.astype('int16'))))


def validate(folder):
    folder = Path(folder)
    report = json.loads((folder/'build.json').read_text(encoding='utf-8'))
    for name,digest in report['files'].items():
        require(hashlib.sha256((folder/name).read_bytes()).hexdigest() == digest,f'Changed deliverable: {name}')
    psd = PSDImage.open(folder/'artwork.psd')
    require(psd.color_mode == ColorMode.CMYK and psd.depth == 8,'Not true 8-bit CMYK PSD')
    require(psd.size == (report['width'],report['height']),'Wrong canvas size')
    resolution=psd.image_resources.get_data(Resource.RESOLUTION_INFO)
    require(resolution is not None and resolution.horizontal_unit == resolution.vertical_unit == 1,'Missing PSD PPI metadata')
    require(abs(resolution.horizontal/65536-report['dpi']) < .02 and
            abs(resolution.vertical/65536-report['dpi']) < .02,'Wrong PSD resolution')
    icc = psd.image_resources.get_data(Resource.ICC_PROFILE)
    require(isinstance(icc,bytes) and icc[16:20] == b'CMYK' and icc[36:40] == b'acsp','Missing/invalid CMYK ICC')
    require(hashlib.sha256(icc).hexdigest() == report['profile_sha256'],'Wrong PSD ICC')
    specs = report['layers']
    # psd-tools exposes on-disk bottom-to-top record order.
    layers = list(psd)
    require([l.name for l in layers] == [s['name'] for s in specs],'Layer names/order changed')
    require(len(layers) == len(specs) >= 2,'Missing real layers')
    decoded = []
    for layer,spec in zip(layers,specs):
        require(layer.kind == 'pixel' and layer.visible,'Unexpected non-pixel or hidden layer')
        require(layer.bbox == (spec['x'],spec['y'],spec['x']+spec['width'],spec['y']+spec['height']),'Wrong layer position')
        require(layer.opacity == spec['opacity'],'Wrong opacity')
        require(layer.blend_mode.value == b'norm','Wrong blend mode')
        color = layer.numpy('color')
        alpha = layer.numpy('shape')
        require(color is not None and color.shape[2] == 4,'Missing CMYK layer channels')
        require(alpha is not None and alpha.max() > 0,'Missing/empty layer transparency')
        decoded.append((layer,1-color,alpha))
    # Independent channel-based compositor; use only the decoded saved file.
    def render(omit=None,move=None):
        out = np.zeros((psd.height,psd.width,4),np.float32)
        for index,(layer,color,alpha) in enumerate(decoded):
            if index == omit:
                continue
            x,y = layer.left,layer.top
            if index == move:
                x += max(1,min(17,psd.width//10))
            x0,y0 = max(x,0),max(y,0)
            x1,y1 = min(x+layer.width,psd.width),min(y+layer.height,psd.height)
            if x1<=x0 or y1<=y0:
                continue
            a = alpha[y0-y:y1-y,x0-x:x1-x]*layer.opacity/255
            c = color[y0-y:y1-y,x0-x:x1-x]
            roi = out[y0:y1,x0:x1]
            roi[:] = c*a + roi*(1-a)
        return np.clip(np.rint(out*255),0,255).astype('uint8')
    recomposed = render()
    # Use the reader's own compositor as well, bypassing the cached preview.
    # psd-tools 1.12.1 high-level force=True PIL CMYKA path is unsupported;
    # the low-level 4-channel float compositor is the verified route here.
    independent,_,alpha = independent_composite(psd,force=True)
    independent = np.clip(np.rint((1-independent)*255),0,255).astype('uint8')
    require(np.allclose(alpha,1),'Unexpected transparent paper canvas')
    require(maxdiff(recomposed,independent) <= 1,'Independent compositor disagrees; inspect order/blending')
    merged = psd.topil(apply_icc=False)
    require(merged is not None and merged.mode == 'CMYK','Missing CMYK merged preview')
    require(maxdiff(recomposed,np.array(merged)) <= 1,'Layer recomposition differs from internal preview')
    with Image.open(folder/'artwork-cmyk.tif') as tif:
        require(tif.mode == 'CMYK' and tif.size == psd.size,'Wrong TIFF mode/size')
        require(tif.info.get('icc_profile') == icc,'TIFF/PSD profiles differ')
        require(maxdiff(recomposed,np.array(tif)) <= 1,'TIFF differs from actual layers')
        require(all(abs(float(v)-report['dpi']) < .02 for v in tif.info['dpi']),'Wrong TIFF resolution')
    srgb = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'))
    expected_preview = ImageCms.profileToProfile(merged,ImageCms.ImageCmsProfile(io.BytesIO(icc)),srgb,
        outputMode='RGB',renderingIntent=ImageCms.Intent.RELATIVE_COLORIMETRIC,
        flags=ImageCms.Flags.BLACKPOINTCOMPENSATION)
    with Image.open(folder/'preview-rgb.png') as png:
        require(png.mode == 'RGB' and png.size == psd.size,'Preview must be RGB PNG')
        p = ImageCms.ImageCmsProfile(io.BytesIO(png.info['icc_profile']))
        require('srgb' in ImageCms.getProfileDescription(p).lower(),'Preview profile is not sRGB')
        require(maxdiff(np.array(expected_preview),np.array(png)) <= 1,'RGB preview is inconsistent')
    tests=[]
    # Test every non-background layer, not only a fixed superficial count.
    review_dir=folder/'qa-renders'
    review_dir.mkdir(exist_ok=True)
    def preview_for_review(inks,path):
        image=ImageCms.profileToProfile(Image.fromarray(inks,'CMYK'),ImageCms.ImageCmsProfile(io.BytesIO(icc)),srgb,
            outputMode='RGB',renderingIntent=ImageCms.Intent.RELATIVE_COLORIMETRIC,
            flags=ImageCms.Flags.BLACKPOINTCOMPENSATION)
        image.save(path,icc_profile=srgb.tobytes())
    for index,(layer,_,_) in enumerate(decoded[1:],start=1):
        hide = maxdiff(recomposed,render(omit=index))
        move = maxdiff(recomposed,render(move=index))
        require(hide > 0 and move > 0,f'{layer.name}: invisible or blocked component; inspect redundancy/overlays')
        preview_for_review(render(omit=index),review_dir/f'{index:03d}-hidden-rgb.png')
        preview_for_review(render(move=index),review_dir/f'{index:03d}-moved-rgb.png')
        tests.append(dict(name=layer.name,hide_difference=hide,move_difference=move))
    result = dict(status='technical_checks_passed_visual_review_required',reader='psd-tools 1.12.1',
        width=psd.width,height=psd.height,color_mode='CMYK',depth=psd.depth,
        icc=report['profile'],layer_count=len(layers),layer_order_top_to_bottom=[l.name for l in reversed(layers)],
        layer_independence=tests,photoshop_tested=False,
        pending=['Visual comparison including skin/brand/dark colors and halos',
                 'Persian/Latin text and font review',
                 'Hide/move in an editor and inspect background for baked-in duplicate subjects',
                 'Confirm effective source resolution, trim/bleed, paper and printer approval',
                 'Photoshop open/edit test when Photoshop is available'])
    (folder/'qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return result


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('output')
    args=parser.parse_args()
    validate(args.output)
