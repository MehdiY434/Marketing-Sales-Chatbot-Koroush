#!/usr/bin/env python3
"""Integration + negative checks using procedural fixtures (not generated artwork)."""
import argparse
import json
import subprocess
import sys
from pathlib import Path

from PIL import Image,ImageDraw

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from build import build,load_job
from render_text import render
from validate import validate


def main(root,icc,font):
    root=Path(root).resolve()
    root.mkdir(parents=True,exist_ok=False)
    Image.new('RGB',(400,300),'#e5d9c0').save(root/'background.png')
    subject=Image.new('RGBA',(130,160))
    draw=ImageDraw.Draw(subject)
    draw.ellipse((5,5,125,155),fill=(20,145,185,255))
    draw.ellipse((20,20,70,70),fill=(255,255,255,110))
    subject.save(root/'subject.png')
    Image.new('RGBA',(20,20)).save(root/'empty.png')
    shadow=Image.new('RGBA',(160,40))
    ImageDraw.Draw(shadow).ellipse((1,1,159,39),fill=(0,0,0,70))
    shadow.save(root/'shadow.png')
    render('فروش ویژه ۱۴۰۵\nCMYK — 25%',font,26,root/'text.png')
    job=dict(width=400,height=300,dpi=300,icc=str(Path(icc).resolve()),
        profile_reason='TEST ONLY: Artifex SWOP fixture, not a printer-approved choice',
        assume_untagged_srgb=True,bleed_mm=0,layers=[
            dict(name='پس‌زمینه',role='background',file='background.png',provenance='procedural QA fixture'),
            dict(name='سایه',role='shadow',file='shadow.png',x=110,y=210,opacity=180,provenance='procedural QA fixture'),
            dict(name='محصول مستقل',role='subject',file='subject.png',x=120,y=65,provenance='procedural QA fixture'),
            dict(name='تیتر فارسی / Latin',role='text-raster',file='text.png',x=15,y=5,provenance='raster text QA fixture')])
    manifest=root/'job.json'
    manifest.write_text(json.dumps(job,ensure_ascii=False,indent=2),encoding='utf-8')
    build(manifest,root/'output')
    validate(root/'output')
    # Second independent external reader must identify the CMYK image and 4 layers.
    r=subprocess.run(['magick','identify','-format','%m|%[colorspace]|%w|%h\n',str(root/'output/artwork.psd')],
        text=True,capture_output=True,check=True)
    lines=r.stdout.strip().splitlines()
    assert len(lines)==5 and all('CMYK' in x for x in lines),r.stdout+r.stderr
    print('PASS independent ImageMagick:',r.stdout)
    raw=subprocess.run(['magick',str(root/'output/artwork.psd')+'[0]','-depth','8','cmyk:-'],
        capture_output=True,check=True).stdout
    import numpy as np
    with Image.open(root/'output/artwork-cmyk.tif') as tif:
        reference=np.array(tif)
    assert np.max(np.abs(np.frombuffer(raw,dtype='uint8').reshape(reference.shape).astype('int16')-reference))<=1
    print('PASS ImageMagick CMYK merged pixels match TIFF')
    for label,mutate in [
        ('duplicate layer',lambda j:j['layers'].append(dict(j['layers'][2],name='duplicate'))),
        ('RGB instead of CMYK ICC',lambda j:j.update(icc='/usr/share/color/icc/sRGB.icc')),
        ('missing source color assumption',lambda j:j.update(assume_untagged_srgb=False)),
        ('unsupported blend mode',lambda j:j['layers'][2].update(blend='multiply')),
        ('empty transparent layer',lambda j:j['layers'][2].update(file='empty.png')),
        ('missing print assumption',lambda j:j.update(profile_reason=''))]:
        modified=json.loads(json.dumps(job))
        mutate(modified)
        manifest.write_text(json.dumps(modified),encoding='utf-8')
        try:
            load_job(manifest)
        except ValueError:
            print('PASS rejection:',label)
        else:
            raise AssertionError('Invalid job accepted: '+label)
    manifest.write_text(json.dumps(job,ensure_ascii=False,indent=2),encoding='utf-8')
    # Font coverage failure must not quietly produce missing-glyph boxes.
    import unicodedata
    from fontTools.ttLib import TTFont
    with TTFont(str(font)) as face:
        cmap=face.getBestCmap()
    missing=next(chr(i) for i in range(0x80,0x30000) if i not in cmap and unicodedata.category(chr(i)).startswith('L'))
    try:
        render(missing,font,26,root/'missing-glyph.png')
    except ValueError:
        print('PASS missing font glyph rejected')
    else:
        raise AssertionError('Missing glyph silently rendered')
    try:
        build(manifest,root/'output')
    except FileExistsError:
        print('PASS existing deliverables protected')
    else:
        raise AssertionError('Deliverables overwritten')
    # Tamper with the PSD structure but update the hash, ensuring structural QA
    # (rather than merely a checksum) catches a wrong document mode.
    import hashlib
    psd_path=root/'output/artwork.psd'
    good=psd_path.read_bytes()
    corrupted=good[:24]+b'\0\x03'+good[26:]  # RGB header, CMYK channels still present.
    psd_path.write_bytes(corrupted)
    report_path=root/'output/build.json'
    good_report=report_path.read_text(encoding='utf-8')
    report=json.loads(good_report)
    report['files']['artwork.psd']=hashlib.sha256(corrupted).hexdigest()
    report_path.write_text(json.dumps(report),encoding='utf-8')
    try:
        validate(root/'output')
    except ValueError:
        print('PASS structural QA rejects falsely labeled RGB PSD even with updated checksum')
    else:
        raise AssertionError('Wrong mode passed QA')
    finally:
        psd_path.write_bytes(good)
        report_path.write_text(good_report,encoding='utf-8')
    print('PASS all integration checks; Photoshop NOT tested; visual inspection still required')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('output')
    p.add_argument('--icc',required=True)
    p.add_argument('--font',required=True)
    a=p.parse_args()
    main(a.output,a.icc,a.font)
