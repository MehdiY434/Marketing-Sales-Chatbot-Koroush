"""Transfer actual host file bytes to a one-use upload URL returned by MCP.
Usage: python scripts/host_upload.py subject.png
Paste the ticket URL at the prompt (not a credential in source or argv logs).
No arbitrary remote fetching; this script only uploads the selected local file.
"""
import getpass
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit
from urllib.request import Request,urlopen

path=Path(sys.argv[1])
url=getpass.getpass('One-use upload URL: ')
u=urlsplit(url)
if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('127.0.0.1','localhost')):
    raise SystemExit('HTTPS is required except for loopback development')
if not u.path.startswith('/upload/') or u.username or u.password:
    raise SystemExit('Use the exact upload capability returned by create_upload_ticket')
if not 0<path.stat().st_size<=16*1024*1024:raise SystemExit('Expected a file up to 16 MiB')
request=Request(url,data=path.read_bytes(),method='PUT',headers={'Content-Type':'application/octet-stream'})
with urlopen(request,timeout=120) as response:
    result=json.load(response)
print(json.dumps(result,ensure_ascii=False,indent=2))
