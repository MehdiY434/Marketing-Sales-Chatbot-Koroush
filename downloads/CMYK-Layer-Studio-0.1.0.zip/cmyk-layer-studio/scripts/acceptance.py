"""Run the actual sample locally, optionally through a running MCP server.
No credentials, public deployment, or Photoshop are assumed.
"""
import argparse
import asyncio
from hashlib import sha256
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.parse import urlsplit
import numpy as np
from PIL import Image
from psd_tools import PSDImage
from cmyk_studio.demo import demo_design
from cmyk_studio.storage import Store
from cmyk_studio.pipeline import build
from cmyk_studio.validate import _compose_readback
from cmyk_studio.color import ManagedColor
from psd_tools.constants import Resource


def independent_evidence(output):
    psd=PSDImage.open(output/'design.psd')
    icc=psd.image_resources.get_data(Resource.ICC_PROFILE)
    manager=ManagedColor(icc)
    original=_compose_readback(psd,psd.size)
    subject=next(i for i,l in enumerate(psd) if l.name=='محصول مستقل')
    logo=next(i for i,l in enumerate(psd) if l.name=='لوگوی اصلی نمونه')
    hidden=_compose_readback(psd,psd.size,omit=subject)
    moved=_compose_readback(psd,psd.size,move=(logo,-170,80))
    for name,arr in [('hidden-subject.png',hidden),('moved-logo.png',moved)]:
        manager.to_rgb(Image.fromarray(arr,'CMYK')).save(output/name)
    # Persist actual layer visibility and position changes, then independently reopen.
    with tempfile.TemporaryDirectory() as tmp:
        psd[subject].visible=False
        psd.save(Path(tmp)/'hidden.psd')
        reread=PSDImage.open(Path(tmp)/'hidden.psd')
        assert reread[subject].visible is False
        assert np.array_equal(_compose_readback(reread,reread.size),hidden)
        psd=PSDImage.open(output/'design.psd')
        psd[logo].offset=(psd[logo].left-170,psd[logo].top+80)
        psd.save(Path(tmp)/'moved.psd')
        reread=PSDImage.open(Path(tmp)/'moved.psd')
        assert np.array_equal(_compose_readback(reread,reread.size),moved)
    checks=dict(persisted_hide_subject=True,persisted_move_logo=True,
                hide_changed_pixels=int(np.any(original!=hidden,axis=-1).sum()),
                move_changed_pixels=int(np.any(original!=moved,axis=-1).sum()))
    if shutil.which('magick'):
        identify=subprocess.run(['magick','identify','-format','%[colorspace] %n\n',str(output/'design.psd')],check=True,capture_output=True,text=True)
        raw=output/'cross-read.cmyk'
        subprocess.run(['magick',str(output/'design.psd')+'[0]','-depth','8','CMYK:'+str(raw)],check=True,capture_output=True)
        assert raw.read_bytes()==PSDImage.open(output/'design.psd').topil(apply_icc=False).tobytes()
        raw.unlink()
        checks['imagemagick']=dict(status='passed',scenes=identify.stdout.strip().splitlines(),merged_pixels='exact match')
    else:checks['imagemagick']={'status':'unrun','reason':'optional reader not installed'}
    return checks


async def via_mcp(design,store,server,output):
    import httpx
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    if urlsplit(server).hostname not in ('127.0.0.1','localhost'):
        raise ValueError('This acceptance harness targets a local server; verify remote OAuth separately')
    async with httpx.AsyncClient(timeout=180,trust_env=False) as http:
        async with streamable_http_client(server+'/mcp',http_client=http) as (read,write,_):
            async with ClientSession(read,write) as session:
                await session.initialize()
                async def call(name,args):
                    result=await session.call_tool(name,args)
                    if result.isError:raise ValueError(str(result.content))
                    return result.structuredContent or json.loads(result.content[0].text)
                await call('plan_design',dict(brief=design.brief,width=design.width,height=design.height,dpi=design.dpi))
                ids={}
                payload=design.model_dump()
                for layer in payload['layers']:
                    for field,kind in [('asset_id','image'),('font_id','font')]:
                        old=layer[field]
                        if not old:continue
                        if old not in ids:
                            path,meta=store.asset(old,kind)
                            ticket=await call('create_upload_ticket',dict(kind=kind,filename=meta['filename'],provenance=meta['provenance']))
                            response=await http.put(ticket['url'],content=path.read_bytes(),headers={'Content-Type':'application/octet-stream'})
                            response.raise_for_status()
                            uploaded=response.json()
                            assert uploaded['sha256']==meta['sha256']
                            ids[old]=uploaded['asset_id']
                        layer[field]=ids[old]
                result=await call('render_design',dict(design=payload))
                if result['status']!='passed':raise ValueError(str(result['summary']))
                recheck=await call('validate_output',dict(job_id=result['job_id']))
                assert recheck['status']=='passed'
                for name,url in result['files'].items():
                    response=await http.get(url);response.raise_for_status()
                    (output/name).write_bytes(response.content)
                studio=await call('open_studio',dict(design=payload))
                # Keep capability out of reports; return it only for the local browser check.
                return dict(status='passed',uploaded_assets=len(ids),revalidation=recheck['status']),studio['url']


def browser_check(url,output):
    from playwright.sync_api import sync_playwright,expect
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
        page=browser.new_page(viewport={'width':1440,'height':1050})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url)
        expect(page.locator('html')).to_have_attribute('dir','rtl')
        expect(page.locator('#custom')).not_to_be_checked()
        expect(page.locator('#subtitle')).to_have_value('مراقبت روزانه | SERUM 30 ml')
        page.locator('#render').click()
        expect(page.locator('#status')).to_contain_text('ساخته و بازخوانی شدند',timeout=180000)
        expect(page.locator('#preview')).to_be_visible()
        page.wait_for_function("document.getElementById('preview').naturalWidth === 1024")
        assert page.locator('#downloads a').count()>=4
        page.screenshot(path=str(output/'workbench.png'),full_page=True)
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        assert not errors,errors
        browser.close()
    return dict(status='passed',rtl=True,real_render=True,download_links=True,mobile_no_overflow=True,pageerrors=errors)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('acceptance'))
    parser.add_argument('--server',default=None);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        store=Store(Path(tmp)/'store');design=demo_design(store)
        if args.server:
            remote,url=asyncio.run(via_mcp(design,store,args.server.rstrip('/'),args.output))
            browser=browser_check(url,args.output)
        else:
            report,path=build(design,store)
            if report['status']!='passed':raise ValueError(report)
            for name in (*report['files'],'report.json','delivery.zip'):shutil.copy2(path/name,args.output/name)
            remote={'status':'unrun'};browser={'status':'unrun'}
    checks=independent_evidence(args.output)
    report=json.loads((args.output/'report.json').read_text())
    summary=dict(status='passed',sample=dict(width=report['width'],height=report['height'],dpi=report['dpi'],layers=report['layer_count'],profile=report['profile']),
                 mcp=remote,browser=browser,independent=checks,photoshop_tested=False,
                 text='raster RAQM; visually inspect Persian and mixed bidi in preview',
                 versions={n:importlib.metadata.version(n) for n in ('Pillow','psd-tools','mcp','numpy')})
    (args.output/'acceptance.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({k:summary[k] for k in ('status','sample','independent','photoshop_tested')},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
