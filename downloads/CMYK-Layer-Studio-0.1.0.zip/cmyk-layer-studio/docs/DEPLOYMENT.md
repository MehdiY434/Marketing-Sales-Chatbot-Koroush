# اتصال واقعی به ChatGPT و استقرار

## مسیر پشتیبانی‌شده

این محصول یک MCP App است. طبق نمونه رسمی OpenAI، برای حساب دارای Developer Mode، یک سرور Streamable HTTP عمومی با مسیر `/mcp` را در بخش Apps/Connectors تنظیمات ChatGPT به‌عنوان Custom App اضافه کنید. نام منوها و دسترسی حساب ممکن است متفاوت باشد. منبع بررسی‌شده: https://github.com/openai/openai-apps-sdk-examples (README: اجرای MCP و اتصال Developer Mode). ایجاد اتصال در حساب کاربر به دسترسی خود حساب نیاز دارد؛ این پروژه آن را از راه دور انجام نمی‌دهد.

۱. سرور را روی دامنه واقعی HTTPS، با TLS معتبر، اجرا کنید. loopback در ChatGPT ابری قابل دسترسی نیست.
۲. یک ارائه‌دهنده OAuth سازگار با MCP/ChatGPT تنظیم کنید: Authorization Code + PKCE، discovery، client registration یا ثبت دستی client طبق امکانات همان حساب/ارائه‌دهنده، scope به نام `studio`، JWT امضاشده RS256 با `sub`, `iss`, `aud`, `exp`. Redirect URI دقیق را از صفحه اتصال ChatGPT بردارید؛ آدرس حدسی وارد نکنید.
۳. issuer، JWKS و audience را در متغیرهای امن سرور قرار دهید. audience پیش‌فرض دقیقاً نشانی عمومی `/mcp` است. JWKS باید کلیدهای عمومی همان issuer را بدهد. OAuth provider مستقل است؛ این پروژه سرویس login یا client-secret سازنده نیست.
۴. health و discovery منبع محافظت‌شده را بررسی کنید. `POST /mcp` بدون توکن معتبر باید 401 بدهد. حساب دیگری نباید دارایی‌های این کاربر را بخواند.
۵. آدرس `https://YOUR-DOMAIN/mcp` را به ChatGPT اضافه و OAuth را تکمیل کنید. ابزار `studio_capabilities` سپس نمونه `render_design` و `validate_output` را از داخل گفت‌وگو اجرا کنید. تا این مرحله انجام نشود، «نصب در ChatGPT انجام شده» نگویید.

در حالت استقرار، public origin تعیین‌شده برای Host/Origin مجاز MCP نیز استفاده می‌شود؛ DNS rebinding protection غیرفعال نشده است. reverse proxy باید Host اصلی را حفظ کند، HTTPS را terminate کند، بدنه حداقل ۲۴ MiB و زمان پاسخ متناسب با اندازه طرح داشته باشد. یک worker استفاده کنید؛ محدودکننده CPU داخل فرایند است. اپ/پروکسی باید log نشانی‌های ticketدار را غیرفعال کند و سیاست quota/retention مناسب روی volume اعمال شود.

## متغیرها

| نام | معنی | محرمانه؟ |
| --- | --- | --- |
| `CMYK_PUBLIC_BASE_URL` | فقط origin عمومی HTTPS بدون مسیر؛ نمونه `https://studio.example.com` | خیر |
| `CMYK_DATA_DIR` | مسیر volume خصوصی برای کارها و دارایی‌ها؛ CLI با `--data-dir` تعیین می‌کند | خیر |
| `CMYK_OAUTH_ISSUER` | issuer دقیق ارائه‌دهنده OAuth، شامل slash انتهایی اگر صادرکننده دارد | خیر |
| `CMYK_OAUTH_JWKS_URL` | نشانی HTTPS کلیدهای عمومی صادرکننده | خیر |
| `CMYK_OAUTH_AUDIENCE` | مخاطب JWT؛ پیش‌فرض BASE + `/mcp` | خیر |

سرور برای اعتبارسنجی resource server به client secret نیاز ندارد. اگر flow ثبت client ارائه‌دهنده به secret نیاز دارد، آن را در تنظیمات امن OAuth/ChatGPT نگه دارید؛ این مقادیر در کد یا فایل طراحی قرار نمی‌گیرند. هیچ توکن تصویرساز برای رندر داخلی لازم نیست.

## Docker

```bash
docker build -t cmyk-layer-studio:0.1.0 .
docker volume create cmyk-studio-data
docker run --rm --name cmyk-studio -p 127.0.0.1:8765:8765 \
  --env-file /secure/location/cmyk-runtime.env \
  -v cmyk-studio-data:/data cmyk-layer-studio:0.1.0
```

فایل runtime.env باید origin واقعی و متغیرهای OAuth بالا را داشته باشد. مقادیر نمونه/دامنه ساختگی را فعال نکنید. image با کاربر غیرroot اجرا می‌شود؛ Docker volume تازه مالکیت `/data` را از image می‌گیرد. برای bind mount مالکیت دایرکتوری را از قبل برای UID 10001 آماده کنید. پایگاه داده بیرونی، Photoshop و VPN لازم نیست. برای نصب وابستگی‌ها DockerHub، Debian و PyPI و برای زمان اجرا JWKS صادرکننده لازم‌اند.

پس از استقرار، اجرا از داخل ChatGPT، consent OAuth، دریافت فایل‌ها و اعتبارسنجی مجدد را بررسی کنید. Docker build یا اتصال محلی به MCP این بررسی حساب را جایگزین نمی‌کند. بسته ZIP و wheel توزیع نرم‌افزار هستند و از مسیر Upload Plugin در ChatGPT نصب نمی‌شوند؛ چنین مسیری در این نشست در دسترس نبود.

## استفاده محلی با کلاینت MCP

کلاینت پشتیبان Streamable HTTP می‌تواند با transport نوع http به `/mcp` متصل شود. برای حالت loopback خصوصی احراز هویت غیرفعال است. تغییر bind به 0.0.0.0 بدون OAuth رد می‌شود. برای سیستم‌های مشترک، حتی دسترسی محلی را نیز از طریق OAuth و جداسازی OS محدود کنید.

اگر سازنده کانتینر پشت پراکسی سازمانی است، متغیرهای پراکسی را با `--build-arg HTTP_PROXY --build-arg HTTPS_PROXY --build-arg http_proxy --build-arg https_proxy` به نام ارسال کنید، نه با قراردادن مقادیر محرمانه در Dockerfile. در شبکه ساخت، نام پراکسی باید قابل resolve باشد. برای زنجیره اعتماد سازمانی، Dockerfile از secret اختیاری `--secret id=studio_ca_bundle,src=/path/to/trusted-ca-bundle.pem` پشتیبانی می‌کند. این فایل فقط bundle گواهی‌های عمومی مورداعتماد است، نه کلید خصوصی. برای خوانده‌شدن توسط sandbox کاربر apt، mount آن 0444 است. CA فقط در مراحل دریافت بسته‌ها استفاده می‌شود و داخل لایه image ذخیره نمی‌شود. TLS، امضای apt و هش‌های pip باید فعال بمانند. در محیط ساخت این پروژه، نام پراکسی از DNS معتبر میزبان در شبکه build ثبت شد و bundle اعتماد موجود میزبان برای ساخت استفاده شد.
