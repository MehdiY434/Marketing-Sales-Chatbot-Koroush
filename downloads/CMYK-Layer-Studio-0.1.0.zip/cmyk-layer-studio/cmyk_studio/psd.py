"""Minimal PSD v1 writer: 8-bit CMYK, normal pixel layers, alpha, ICC, Unicode names.
PSD CMYK color samples are stored inverted. Alpha is NOT inverted.
No native text, smart objects, groups, mask blocks, or Photoshop layer effects.
"""
import struct
from dataclasses import dataclass
import numpy as np
from PIL import Image

p=lambda fmt,*args:struct.pack('>'+fmt,*args)
def block(data):return p('I',len(data))+data

def resource(ident,data):
    return b'8BIM'+p('H',ident)+b'\0\0'+block(data)+(b'\0' if len(data)%2 else b'')

@dataclass
class InkLayer:
    name: str
    role: str
    ink: Image.Image
    alpha: Image.Image
    x: int
    y: int
    metadata: dict


def convert_layers(layers,color):
    return [InkLayer(l.name,l.role,color.to_cmyk(l.rgba),l.rgba.getchannel('A'),l.x,l.y,l.metadata) for l in layers]


def compose(layers,size):
    canvas=Image.new('CMYK',size,(0,0,0,0))
    for l in layers:canvas.paste(l.ink,(l.x,l.y),l.alpha)
    return canvas


def write_psd(path,layers,size,icc,dpi=300):
    records=[];channel_data=[]
    for index,l in enumerate(layers):
        width,height=l.ink.size
        data=[bytes(255-np.asarray(c,dtype=np.uint8)) for c in l.ink.split()]+[l.alpha.tobytes()]
        ids=[0,1,2,3,-1]
        # Legacy Pascal name occupies four bytes. Unicode luni contains the full name.
        extra=p('II',0,0)+b'\x01?\0\0'
        unicode=l.name.encode('utf-16-be')
        uni=p('I',len(unicode)//2)+unicode
        if len(uni)%2:uni+=b'\0'
        extra+=b'8BIMluni'+block(uni)+b'8BIMlyid'+block(p('I',index+1))
        record=p('iiiiH',l.y,l.x,l.y+height,l.x+width,5)
        record+=b''.join(p('hI',ch,len(d)+2) for ch,d in zip(ids,data))
        record+=b'8BIMnorm'+p('BBBB',255,0,0,0)+block(extra)
        records.append(record)
        channel_data.extend(p('H',0)+d for d in data)
    layer_info=p('h',len(layers))+b''.join(records)+b''.join(channel_data)
    if len(layer_info)%2:layer_info+=b'\0'
    resources=resource(1039,icc)+resource(1005,p('IHHIHH',dpi<<16,1,1,dpi<<16,1,1))
    merged=compose(layers,size)
    header=b'8BPS'+p('H',1)+b'\0'*6+p('HIIHH',4,size[1],size[0],8,4)
    with open(path,'wb') as f:
        f.write(header+block(b'')+block(resources)+block(block(layer_info)+p('I',0))+p('H',0))
        for c in merged.split():f.write(bytes(255-np.asarray(c,dtype=np.uint8)))
