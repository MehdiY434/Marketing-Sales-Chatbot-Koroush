"""CMYK Layer Studio: honest, color-managed raster layer production."""
__version__ = "0.1.0"
