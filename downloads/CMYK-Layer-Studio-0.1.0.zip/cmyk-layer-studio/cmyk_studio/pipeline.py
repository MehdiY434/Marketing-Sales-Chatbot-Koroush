import json
import traceback
import zipfile
from hashlib import sha256
from pathlib import Path
from PIL import Image, PngImagePlugin
import numpy as np
from .models import Design
from .color import ManagedColor, DEFAULT_PROFILE, SRGB_BYTES, color_report
from .render import prepare_layers, compose_rgb
from .psd import convert_layers, write_psd
from .validate import validate_psd, validate_deliverables

ARTIFACTS={'design.psd','design-cmyk.tiff','preview-srgb.png','report.json','components.zip','delivery.zip','design.json'}


def build(design: Design,store):
    job,path=store.new_job()
    (path/'design.json').write_text(design.model_dump_json(indent=2),encoding='utf-8')
    manifest=[];layers=[];icc=None
    try:
        layers=prepare_layers(design,store)
        for i,l in enumerate(layers):
            fname=f'component-{i+1:02d}.png'
            l.rgba.save(path/fname,icc_profile=SRGB_BYTES)
            manifest.append(dict(name=l.name,role=l.role,file=fname,x=l.x,y=l.y,size=l.rgba.size,**l.metadata))
        if design.profile_id:profilepath,_=store.asset(design.profile_id,'icc')
        else:profilepath=DEFAULT_PROFILE
        if not profilepath.is_file():raise ValueError('No CMYK ICC available. Upload a print-shop output ICC; Ghostscript default was not found')
        icc=profilepath.read_bytes()
        color=ManagedColor(icc,design.rendering_intent)
        ink=convert_layers(layers,color)
        write_psd(path/'design.psd',ink,(design.width,design.height),icc,design.dpi)
        validation,merged=validate_psd(path/'design.psd',design,icc,ink)
        # All delivery views are produced from the independent readback of the FINAL file.
        merged.save(path/'design-cmyk.tiff',icc_profile=icc,dpi=(design.dpi,design.dpi),compression='tiff_lzw')
        preview=color.to_rgb(merged)
        metadata=PngImagePlugin.PngInfo();metadata.add_text('Description','پیش‌نمایش RGB')
        preview.save(path/'preview-srgb.png',icc_profile=SRGB_BYTES,pnginfo=metadata,dpi=(design.dpi,design.dpi))
        sibling=validate_deliverables(path/'design.psd',path/'design-cmyk.tiff',path/'preview-srgb.png',icc,design)
        before=compose_rgb(layers,(design.width,design.height))
        colors=color_report(before,preview,design.color_checks,color)
        tac=np.asarray(merged,dtype=np.uint16).sum(axis=-1)/255*100
        warnings=['Text is rasterized in separate layers; no native text, Smart Objects, native masks or Photoshop effects are created.',
                  'Photoshop was not available. Parsed by psd-tools with independent layer recomposition and pixel checks.',
                  'RGB preview simulates the embedded CMYK profile; monitor/paper/press appearance can differ.']
        if not design.profile_id:
            warnings.append('Assumed Artifex CMYK SWOP profile for US coated offset; no print-shop/paper specification was verified. Not approved for any specific printer.')
        else:
            warnings.append('User-supplied ICC was embedded; this alone is not press approval or a contract proof.')
        if design.bleed_mm:
            warnings.append(f'Canvas is supplied pixel size; {design.bleed_mm} mm bleed is declared, not automatically added. Verify trim and safe area before print.')
        warnings.extend(l.metadata['warning'] for l in layers if 'warning' in l.metadata)
        if design.ink_limit_percent and tac.max()>design.ink_limit_percent:
            warnings.append('Total ink exceeds the requested limit. No silent clipping was applied; printer review/reprofiling is required.')
        report=dict(status='passed',job_id=job,title=design.title,width=design.width,height=design.height,
                    dpi=design.dpi,physical_mm=[design.width/design.dpi*25.4,design.height/design.dpi*25.4],
                    layer_count=len(layers),layer_order='bottom to top',layers=manifest,
                    profile=color.metadata(),profile_source='user' if design.profile_id else 'assumed default',
                    printer_approved=False,text_editability='raster',photoshop_tested=False,
                    validation=validation,deliverable_validation=sibling,color_review=colors,
                    ink=dict(max_percent=float(tac.max()),requested_limit_percent=design.ink_limit_percent),warnings=warnings)
    except Exception as e:
        # Partial/invalid PSDs are never published or renamed into success.
        for fname in ('design.psd','design-cmyk.tiff','preview-srgb.png'):
            (path/fname).unlink(missing_ok=True)
        report=dict(status='failed',job_id=job,error=f'{type(e).__name__}: {e}',
                    fallback='components.zip' if manifest else None,
                    note='No validated CMYK PSD delivered. Components are a fallback, not the requested final file.')
    if manifest:
        (path/'components.json').write_text(json.dumps(dict(canvas=[design.width,design.height],dpi=design.dpi,layers=manifest),ensure_ascii=False,indent=2))
        with zipfile.ZipFile(path/'components.zip','w',zipfile.ZIP_DEFLATED) as z:
            z.write(path/'components.json','components.json')
            z.write(path/'design.json','design.json')
            for row in manifest:z.write(path/row['file'],row['file'])
            if icc:z.writestr('output-profile.icc',icc)
            z.writestr('ASSEMBLY.txt','Fallback only. Place PNGs on an sRGB canvas at manifest x/y positions in bottom-to-top order. Keep each separate. In Photoshop use Edit > Convert to Profile with output-profile.icc and do not merge layers; embed the profile when saving PSD. Raster text is not editable native text. Verify final CMYK mode, color, and alpha. Reconstruction does not recover original hidden pixels.')
    report['files']={}
    for name in ('design.psd','design-cmyk.tiff','preview-srgb.png','components.zip','design.json'):
        if (path/name).exists():report['files'][name]=dict(bytes=(path/name).stat().st_size,sha256=sha256((path/name).read_bytes()).hexdigest())
    (path/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with zipfile.ZipFile(path/'delivery.zip','w',zipfile.ZIP_DEFLATED) as z:
        for fname in (*report['files'],'report.json'):z.write(path/fname,fname)
    return report,path
