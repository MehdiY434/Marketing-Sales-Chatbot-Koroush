from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import hashlib
import unicodedata
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageColor, features
from fontTools.ttLib import TTFont
from .color import normalize_image

DEFAULT_FONT=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

@dataclass
class RGBLayer:
    name: str
    role: str
    rgba: Image.Image
    x: int
    y: int
    metadata: dict


def prepare_layers(design,store):
    layers=[];seen=set()
    for spec in design.layers:
        size=(spec.width,spec.height)
        meta=dict(kind=spec.kind,provenance=spec.provenance)
        if spec.kind=='image':
            path,asset=store.asset(spec.asset_id,'image')
            with Image.open(path) as raw:
                image=normalize_image(raw)
                meta['input_profile']='embedded' if raw.info.get('icc_profile') else 'assumed sRGB'
            meta.update(asset_sha256=asset['sha256'],source_asset_id=spec.asset_id,
                        asset_provenance=asset['provenance'])
            # Contain without distortion. Original bytes remain untouched in the asset store.
            image.thumbnail(size,Image.Resampling.LANCZOS)
            frame=Image.new('RGBA',size)
            frame.alpha_composite(image,((size[0]-image.width)//2,(size[1]-image.height)//2))
            image=frame
            if spec.role in ('subject','logo') and image.getchannel('A').getextrema()[0]==255:
                meta['warning']='Opaque rectangular asset; use a real alpha PNG or explicit extraction mask for cutouts.'
        elif spec.kind=='text':
            if not features.check('raqm'):
                raise ValueError('Pillow with libraqm (HarfBuzz/FriBidi) is required for verified Persian text')
            fontpath=DEFAULT_FONT if not spec.font_id else store.asset(spec.font_id,'font')[0]
            with TTFont(fontpath) as fontdata:
                cmap=fontdata.getBestCmap()
                missing={c for c in spec.text if not c.isspace() and unicodedata.category(c) not in ('Cf','Cc') and ord(c) not in cmap}
                if missing:raise ValueError('Font lacks glyphs: '+''.join(sorted(missing)))
            font=ImageFont.truetype(str(fontpath),spec.font_size,layout_engine=ImageFont.Layout.RAQM)
            image=Image.new('RGBA',size)
            draw=ImageDraw.Draw(image)
            kwargs=dict(font=font,direction=spec.direction,align=spec.align,spacing=round(spec.font_size*.3))
            box=draw.multiline_textbbox((0,0),spec.text,**kwargs)
            w,h=box[2]-box[0],box[3]-box[1]
            if w>spec.width-4 or h>spec.height-4:
                raise ValueError(f'Text does not fit in layer {spec.name}; enlarge it or reduce font size')
            x={'left':2,'right':spec.width-w-2,'center':(spec.width-w)//2}[spec.align]
            draw.multiline_text((x-box[0],2-box[1]),spec.text,fill=spec.color,**kwargs)
            meta.update(text=spec.text,text_editability='raster pixels; no native Photoshop text',
                        direction=spec.direction,shaping='libraqm / HarfBuzz / FriBidi',
                        font_sha256=hashlib.sha256(fontpath.read_bytes()).hexdigest(),
                        font_asset_id=spec.font_id,font_default=not bool(spec.font_id))
        elif spec.kind=='gradient':
            a=np.array(ImageColor.getrgb(spec.color),float)
            b=np.array(ImageColor.getrgb(spec.color_end),float)
            yy=np.linspace(0,1,size[1])[:,None,None]
            rgb=np.broadcast_to(np.rint(a*(1-yy)+b*yy),(size[1],size[0],3)).astype('uint8')
            image=Image.fromarray(rgb).convert('RGBA')
        else:
            image=Image.new('RGBA',size)
            draw=ImageDraw.Draw(image)
            if spec.kind=='solid':draw.rectangle((0,0,size[0],size[1]),fill=spec.color)
            elif spec.kind in ('ellipse','shadow'):
                pad=max(0,round(spec.blur*2)) if spec.kind=='shadow' else 0
                if pad*2>=min(size):raise ValueError('Shadow blur exceeds layer bounds')
                draw.ellipse((pad,pad,size[0]-pad-1,size[1]-pad-1),fill=spec.color)
            elif spec.kind=='rectangle':draw.rounded_rectangle((0,0,size[0]-1,size[1]-1),radius=spec.radius,fill=spec.color)
        if spec.blur:image=image.filter(ImageFilter.GaussianBlur(spec.blur))
        if spec.rotation:image=image.rotate(spec.rotation,Image.Resampling.BICUBIC,expand=True)
        if spec.opacity!=1:
            image.putalpha(image.getchannel('A').point(lambda a:round(a*spec.opacity)))
        bounds=image.getchannel('A').getbbox()
        if not bounds:raise ValueError('Empty layer rejected: '+spec.name)
        image=image.crop(bounds)
        x,y=spec.x+bounds[0],spec.y+bounds[1]
        # Clip parts outside the canvas, with positions kept explicit in PSD records.
        clip=(max(0,-x),max(0,-y),min(image.width,design.width-x),min(image.height,design.height-y))
        if clip[2]<=clip[0] or clip[3]<=clip[1]:raise ValueError('Layer lies outside canvas: '+spec.name)
        image=image.crop(clip);x+=clip[0];y+=clip[1]
        if not image.getchannel('A').getbbox():raise ValueError('Visible layer is empty: '+spec.name)
        fingerprint=hashlib.sha256(image.tobytes()+str(image.size).encode()).hexdigest()
        if fingerprint in seen:raise ValueError('Duplicate layer pixels rejected: '+spec.name)
        seen.add(fingerprint)
        layers.append(RGBLayer(spec.name,spec.role,image,x,y,meta))
    bg=layers[0]
    if bg.x!=0 or bg.y!=0 or bg.rgba.size!=(design.width,design.height) or bg.rgba.getchannel('A').getextrema()!=(255,255):
        raise ValueError('Background must cover the full canvas with opaque pixels')
    return layers


def compose_rgb(layers,size):
    image=Image.new('RGBA',size)
    for l in layers:image.alpha_composite(l.rgba,(l.x,l.y))
    return image.convert('RGB')


def extract(store,image_id,mask_id):
    source,_=store.asset(image_id,'image');maskpath,_=store.asset(mask_id,'image')
    with Image.open(source) as raw:image=normalize_image(raw)
    with Image.open(maskpath) as raw:mask=raw.convert('L')
    if mask.size!=image.size:raise ValueError('Mask dimensions must match the source; white retains, black removes')
    from PIL import ImageChops
    image.putalpha(ImageChops.multiply(image.getchannel('A'),mask))
    bbox=image.getchannel('A').getbbox()
    if not bbox:raise ValueError('Mask removes the entire component')
    image=image.crop(bbox)
    out=BytesIO();image.save(out,'PNG',icc_profile=__import__('cmyk_studio.color',fromlist=['SRGB_BYTES']).SRGB_BYTES)
    result=store.put_asset(out.getvalue(),'image','extracted-component.png','extracted')
    result.update(source_bounds=bbox,warning='Mask-based extraction; hidden pixels were not recovered. Supply a separately reconstructed background if needed.')
    return result
