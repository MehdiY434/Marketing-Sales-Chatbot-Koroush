from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')

class Layer(Strict):
    name: str = Field(min_length=1, max_length=120)
    role: Literal['background', 'subject', 'logo', 'text', 'decoration', 'effect']
    kind: Literal['image', 'text', 'solid', 'gradient', 'ellipse', 'rectangle', 'shadow']
    x: int = 0
    y: int = 0
    width: int = Field(gt=0, le=6000)
    height: int = Field(gt=0, le=6000)
    asset_id: str | None = None
    color: str = '#000000'
    color_end: str = '#ffffff'
    opacity: float = Field(default=1, gt=0, le=1)
    rotation: float = Field(default=0, ge=-180, le=180)
    radius: int = Field(default=0, ge=0, le=1000)
    blur: float = Field(default=0, ge=0, le=100)
    text: str | None = Field(default=None, max_length=2000)
    font_id: str | None = None
    font_size: int = Field(default=48, ge=6, le=600)
    direction: Literal['rtl', 'ltr'] = 'rtl'
    align: Literal['right', 'left', 'center'] = 'right'
    provenance: Literal['original', 'generated', 'extracted', 'reconstructed'] = 'original'

    @model_validator(mode='after')
    def content(self):
        if self.kind == 'image' and not self.asset_id:
            raise ValueError('Image layer requires an uploaded asset_id')
        if self.kind == 'text' and not self.text:
            raise ValueError('Text layer requires text')
        if any(ord(c) < 32 for c in self.name):
            raise ValueError('Control characters are not allowed in layer names')
        return self

class ColorCheck(Strict):
    name: str = Field(max_length=100)
    srgb: str

class Design(Strict):
    title: str = Field(default='CMYK Layer Studio', max_length=160)
    brief: str = Field(default='', max_length=8000)
    width: int = Field(ge=64, le=6000)
    height: int = Field(ge=64, le=6000)
    dpi: int = Field(default=300, ge=72, le=1200)
    bleed_mm: float = Field(default=0, ge=0, le=20)
    print_notes: str = Field(default='No print-shop specification supplied', max_length=2000)
    profile_id: str | None = None
    rendering_intent: Literal['relative', 'perceptual'] = 'relative'
    ink_limit_percent: int | None = Field(default=None, ge=100, le=400)
    layers: list[Layer] = Field(min_length=2, max_length=24, description='Bottom to top stacking order')
    color_checks: list[ColorCheck] = Field(default_factory=list, max_length=24)

    @model_validator(mode='after')
    def limits(self):
        if self.width * self.height > 16_000_000:
            raise ValueError('Canvas exceeds 16 megapixel safety budget; tile/PSB is not supported')
        if sum(l.width*l.height for l in self.layers) > 48_000_000:
            raise ValueError('Layer pixels exceed 48 megapixel budget')
        if len({l.name for l in self.layers}) != len(self.layers):
            raise ValueError('Layer names must be unique')
        if self.layers[0].role != 'background':
            raise ValueError('First (bottom) layer must be an opaque full-canvas background')
        for l in self.layers:
            if abs(l.x) > 12000 or abs(l.y) > 12000:
                raise ValueError('Layer position exceeds safety limit')
        return self
