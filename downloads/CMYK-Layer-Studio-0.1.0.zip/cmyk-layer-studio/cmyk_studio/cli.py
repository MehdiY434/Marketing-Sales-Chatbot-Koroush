import argparse
import json
from pathlib import Path
from .models import Design
from .storage import Store
from .pipeline import build


def main():
    parser=argparse.ArgumentParser(prog='cmyk-studio')
    parser.add_argument('--data-dir',default='.studio-data')
    sub=parser.add_subparsers(dest='command',required=True)
    serve=sub.add_parser('serve');serve.add_argument('--host',default='127.0.0.1');serve.add_argument('--port',type=int,default=8765)
    asset=sub.add_parser('import');asset.add_argument('file',type=Path);asset.add_argument('--kind',choices=['image','font','icc'],required=True);asset.add_argument('--provenance',default='original')
    render=sub.add_parser('render');render.add_argument('manifest',type=Path)
    sample=sub.add_parser('demo');sample.add_argument('--subject',type=Path)
    args=parser.parse_args()
    if args.command=='serve':
        import os
        os.environ['CMYK_DATA_DIR']=args.data_dir
        if args.host not in ('127.0.0.1','localhost','::1') and not os.environ.get('CMYK_OAUTH_ISSUER'):
            parser.error('Public bind requires OAuth and an HTTPS public origin; see docs/DEPLOYMENT.md')
        import uvicorn
        uvicorn.run('cmyk_studio.server:app',host=args.host,port=args.port,access_log=False)
        return
    store=Store(Path(args.data_dir))
    if args.command=='import':
        print(json.dumps(store.put_asset(args.file.read_bytes(),args.kind,args.file.name,args.provenance),ensure_ascii=False,indent=2))
        return
    if args.command=='demo':
        from .demo import demo_design
        design=demo_design(store,args.subject)
    else:design=Design.model_validate_json(args.manifest.read_text())
    report,path=build(design,store)
    print(json.dumps(dict(status=report['status'],job_id=report['job_id'],output=str(path),error=report.get('error')),ensure_ascii=False,indent=2))
    if report['status']!='passed':raise SystemExit(1)

if __name__=='__main__':main()
