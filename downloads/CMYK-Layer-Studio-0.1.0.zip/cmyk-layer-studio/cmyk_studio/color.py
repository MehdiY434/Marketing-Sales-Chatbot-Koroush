from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import numpy as np
from PIL import Image, ImageCms, ImageColor

SRGB = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'))
SRGB_BYTES = SRGB.tobytes()
DEFAULT_PROFILE = Path('/usr/share/color/icc/ghostscript/default_cmyk.icc')

@dataclass
class ManagedColor:
    data: bytes
    intent: str = 'relative'

    def __post_init__(self):
        if len(self.data) < 128 or self.data[36:40] != b'acsp':
            raise ValueError('Invalid ICC header')
        if int.from_bytes(self.data[:4], 'big') != len(self.data):
            raise ValueError('ICC declared size does not match its bytes')
        self.profile = ImageCms.getOpenProfile(BytesIO(self.data))
        if self.profile.profile.xcolor_space.strip() != 'CMYK':
            raise ValueError('Output ICC must have CMYK device space')
        if self.profile.profile.device_class.strip() != 'prtr':
            raise ValueError('A printer/output ICC profile is required')
        mode = 1 if self.intent == 'relative' else 0
        flags = ImageCms.Flags.BLACKPOINTCOMPENSATION
        self.forward = ImageCms.buildTransform(SRGB, self.profile, 'RGB', 'CMYK', mode, flags)
        self.reverse = ImageCms.buildTransform(self.profile, SRGB, 'CMYK', 'RGB', mode, flags)

    @property
    def description(self):
        return ImageCms.getProfileDescription(self.profile).strip()

    def to_cmyk(self, rgb):
        return ImageCms.applyTransform(rgb.convert('RGB'), self.forward)

    def to_rgb(self, cmyk):
        return ImageCms.applyTransform(cmyk, self.reverse)

    def metadata(self):
        return dict(name=self.description, sha256=sha256(self.data).hexdigest(),
                    space='CMYK', intent=self.intent, black_point_compensation=True,
                    engine='LittleCMS via Pillow', engine_version=ImageCms.core.littlecms_version)


def normalize_image(image: Image.Image):
    """Normalize tagged RGB/CMYK to sRGB; preserve alpha separately."""
    image.load()
    alpha = image.getchannel('A') if 'A' in image.getbands() else Image.new('L', image.size, 255)
    icc = image.info.get('icc_profile')
    if image.mode == 'CMYK' and not icc:
        raise ValueError('CMYK input image needs an embedded ICC profile')
    if icc:
        source = ImageCms.getOpenProfile(BytesIO(icc))
        space = source.profile.xcolor_space.strip()
        if space not in ('RGB','CMYK','GRAY'):
            raise ValueError('Unsupported source ICC space')
        raw = image.convert({'RGB':'RGB','CMYK':'CMYK','GRAY':'L'}[space])
        rgb = ImageCms.profileToProfile(raw, source, SRGB, outputMode='RGB')
    else:
        rgb = image.convert('RGB')  # Explicit documented sRGB assumption for untagged assets.
    rgb.putalpha(alpha)
    return rgb


def lab(rgb):
    arr = np.asarray(rgb.convert('RGB'), dtype=float) / 255
    arr = np.where(arr <= .04045, arr / 12.92, ((arr+.055)/1.055)**2.4)
    xyz = arr @ np.array([[.4124564,.3575761,.1804375], [.2126729,.7151522,.072175], [.0193339,.119192,.9503041]]).T
    xyz /= [.95047,1,1.08883]
    f = np.where(xyz > (6/29)**3, np.cbrt(xyz), xyz/(3*(6/29)**2)+4/29)
    return np.stack([116*f[...,1]-16, 500*(f[...,0]-f[...,1]), 200*(f[...,1]-f[...,2])],axis=-1)


def color_report(before, after, checks, manager):
    # A coarse pixel sample, not a print proof or a perceptual guarantee.
    a,b = before.copy(), after.copy()
    a.thumbnail((320,320)); b.thumbnail((320,320))
    delta=np.linalg.norm(lab(a)-lab(b),axis=-1)
    swatches=[]
    for check in checks:
        source=Image.new('RGB',(1,1),ImageColor.getrgb(check.srgb))
        roundtrip=manager.to_rgb(manager.to_cmyk(source))
        swatches.append(dict(name=check.name,srgb=check.srgb,proof_srgb=roundtrip.getpixel((0,0)),
                             delta_e76=float(np.linalg.norm(lab(source)-lab(roundtrip)))))
    return dict(metric='CIE76, D65 sRGB round-trip simulation, not measured print',
                sampled_mean_delta_e76=float(delta.mean()),sampled_p95_delta_e76=float(np.percentile(delta,95)),
                sampled_max_delta_e76=float(delta.max()),swatches=swatches,
                visual_review_required=True,
                note='Review brand colors, skin, saturated colors, and shadow detail with the printer. No exact RGB/CMYK appearance match is promised.')
