"""Reproducible acceptance design; subject is a bundled host-generated RGBA asset."""
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw
from .models import Design
from .color import SRGB_BYTES
from .render import DEFAULT_FONT


def demo_design(store,subject=None):
    subject=subject or Path(__file__).with_name('assets')/'demo-subject.png'
    product=store.put_asset(subject.read_bytes(),'image','botanical-subject.png','generated')
    # Original demonstration logo, deliberately independent from the generated product.
    logo=Image.new('RGBA',(240,240))
    d=ImageDraw.Draw(logo)
    d.ellipse((12,12,228,228),outline='#275642',width=8)
    d.line((120,180,120,90),fill='#275642',width=9)
    d.ellipse((66,68,120,130),fill='#275642')
    d.ellipse((120,52,174,114),fill='#275642')
    b=BytesIO();logo.save(b,'PNG',icc_profile=SRGB_BYTES)
    brand=store.put_asset(b.getvalue(),'image','original-demo-logo.png','original')
    font=store.put_asset(DEFAULT_FONT.read_bytes(),'font','DejaVuSans.ttf','original')
    return Design.model_validate(dict(title='زیبایی از طبیعت',brief='پوستر نمونه محصول مراقبت پوست، گرم و مینیمال؛ سوژه تولیدشده مستقل و لوگوی نمونه اصلی',
        width=1024,height=1280,dpi=300,print_notes='Acceptance sample only; assumed coated US offset, no printer approval',
        color_checks=[dict(name='رنگ برند سبز',srgb='#275642'),dict(name='شیشه کهربایی اشباع',srgb='#d47d14'),dict(name='سایه تیره',srgb='#302719')],
        layers=[
            dict(name='پس‌زمینه کرم',role='background',kind='gradient',width=1024,height=1280,color='#ece5d3',color_end='#fffaf0'),
            dict(name='دایره تزئینی مستقل',role='decoration',kind='ellipse',x=66,y=430,width=770,height=730,color='#c9d4b4',opacity=.46),
            dict(name='سایه تماس مستقل',role='effect',kind='shadow',x=275,y=988,width=460,height=95,color='#453526',opacity=.28,blur=16),
            dict(name='محصول مستقل',role='subject',kind='image',asset_id=product['asset_id'],x=257,y=365,width=510,height=715,provenance='generated'),
            dict(name='لوگوی اصلی نمونه',role='logo',kind='image',asset_id=brand['asset_id'],x=790,y=48,width=140,height=140),
            dict(name='عنوان فارسی',role='text',kind='text',text='زیبایی از طبیعت',font_id=font['asset_id'],font_size=66,x=90,y=216,width=844,height=115,color='#275642',align='center'),
            dict(name='عنوان لاتین',role='text',kind='text',text='BOTANICAL  /  DAILY CARE',font_id=font['asset_id'],font_size=22,x=95,y=120,width=620,height=55,color='#526b56',direction='ltr',align='left'),
            dict(name='زیرعنوان فارسی و لاتین',role='text',kind='text',text='مراقبت روزانه | SERUM 30 ml',font_id=font['asset_id'],font_size=27,x=100,y=1165,width=824,height=70,color='#275642',align='center')]))
