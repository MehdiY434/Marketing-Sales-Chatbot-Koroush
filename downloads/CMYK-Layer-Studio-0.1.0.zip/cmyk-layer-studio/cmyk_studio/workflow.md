---
name: cmyk-layer-studio
description: Plan meaningful independent graphic components, bridge host-generated assets into the CMYK Layer Studio MCP tools, and deliver independently validated layered CMYK PSD, TIFF and RGB preview.
---

# CMYK Layer Studio

Respond in the user's language; Persian is the default. Reuse all facts in the conversation. Ask only for essential missing dimensions, exact copy, required assets, or material print specifications. Do useful independent work while awaiting optional information.

## Honest capability gate

Call `studio_capabilities`. This engine writes real PSD v1 with 8-bit CMYK normal raster layers, individual alpha, named positions, 300dpi by default and an embedded output ICC. Text is a separate RASTER layer, shaped with RAQM; native Photoshop text, Smart Objects, native masks and native effects are unsupported. Never imply otherwise. The server has NO access to the host's image-generation tool or the user's Photoshop.

## Plan before generating

Use `plan_design` with known brief/dimensions. Adapt its plan to the request before generating. Record bottom-to-top layers: opaque background, optional independent shadow, main product/person, useful independent decorations, original logo, separate final text blocks. Match light, scale, perspective and style across components. Do not make arbitrary slices, duplicate/empty layers, or use one flattened design as multiple fake layers. Avoid occluded layers: the engine rejects them.

For new photography/illustration, if the HOST offers image generation, invoke it separately for each meaningful asset. Request true transparency for subjects/decorations and omit final copy/logos from generated art. Use supplied logo and font files directly. The engine itself supports procedural backgrounds/shapes/shadows/text; it does not secretly call an AI provider. If no generator or suitable asset is available, ask for the needed image or offer a clearly identified procedural design; never fabricate a successful generation.

## Explicit asset handoff

1. Obtain the actual host-generated/uploaded image bytes. A conversation image identifier is not a server-local path.
2. Call `create_upload_ticket(kind='image', filename='subject.png', provenance='generated')`.
3. If the host has shell/network and a real local file, upload the bytes with an HTTP client: PUT that exact file to the returned one-use URL, Content-Type application/octet-stream. For example use Python urllib.request.Request(url, data=Path(local_path).read_bytes(), method='PUT', headers={'Content-Type':'application/octet-stream'}). Do not put untrusted URLs into shell strings. Read JSON asset_id and SHA256.
4. If only small actual bytes are available, call `upload_asset_base64`; base64 is data, never a made-up path. For a user-side file, `open_studio` provides a Persian file picker and returns asset IDs. If the host cannot export image bytes, ask the user to save the generated asset and upload it through that picker. Do not assume an unsupported file-service bridge.
5. Fonts and printer CMYK ICC files use the same mechanism with kind font/icc. Asset originals are retained byte-for-byte; transformations work on copies. Never request credentials in chat, include them in designs, or send assets to an external service without the user's instructed workflow.

For flat images, use a genuine grayscale separation mask and `extract_component`. An automatic segmentation service is not bundled. White retains pixels, black removes them; edges remain alpha. Hidden surfaces must be separately reconstructed through a host editing/generation tool if needed, then uploaded with provenance reconstructed. Clearly distinguish reconstruction from recovery of original layers; exact lost information cannot be recovered. The tool does not invent hidden pixels. Retain source bounds when placing extracted crops.

## Render and check

Submit `render_design` with a Design manifest and uploaded opaque IDs, never server paths. Layers are bottom to top. Position x/y is the original placement box; images fit without distortion, rotate around their local center and may grow in bounds. Keep a full opaque background. Final width/height include any intended bleed: bleed_mm is documentation and does not add pixels. Ask only missing impactful print questions, then choose the printer's CMYK output ICC when provided. Otherwise disclose the Artifex SWOP fallback, assumed US coated offset, and lack of printer approval. Do not say a selected profile is a printer's approval. Tagged inputs are converted to sRGB, untagged RGB is assumed sRGB, untagged CMYK is rejected. LittleCMS converts each layer, preserving alpha, before CMYK document-space composition.

Render final exact copy during assembly, using provided fonts. Check Persian connection, RTL, mixed Persian/Latin sequences and glyph coverage. RAQM shapes/bidi-renders the text; visual review is still necessary. Font files remain original. The resulting text pixels can be moved/replaced but cannot be edited as native Photoshop text.

Read tool status. Only status passed allows delivery as a validated CMYK PSD. Review the report's color shifts (CIE76 simulation, not a print measurement), profile assumptions, ink coverage and warnings. Check especially user-designated brand/skin/saturated swatches and shadow details. Do not promise identical RGB/CMYK appearance. Call `validate_output` if anything changed or to repeat readback checks. Validation uses independent psd-tools; names/order, pixel channels, alpha, dimensions, profile, merged image and hide/move/replace tests are checked. No Photoshop test occurred unless a separate real Photoshop test is supplied. Report the actual level.

## Deliver

Give the returned design.psd, design-cmyk.tiff and preview-srgb.png links (label PNG «پیش‌نمایش RGB»), plus delivery.zip/report as useful. State dimensions, layer count, selected ICC, raster text status and Photoshop-not-tested limitation. Preview comes from the reopened FINAL CMYK PSD, not the preconversion RGB design. Links expire in one hour; `get_delivery` renews them. Session links are scoped capabilities: do not share them beyond the requesting user.

If rendering or validation fails, say so. No RGB/flat file counts as successful CMYK PSD. The engine deletes partial primary deliverables and may return components.zip with source positions and Photoshop assembly guidance. Name it only as a fallback; diagnose/retry a real setup issue where possible. Do not claim success from a fallback.
