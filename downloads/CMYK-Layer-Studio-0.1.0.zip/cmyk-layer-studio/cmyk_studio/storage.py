"""Owner-isolated storage and narrowly scoped expiring upload/download capabilities."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from io import BytesIO
from pathlib import Path
from PIL import Image
from fontTools.ttLib import TTFont
from .color import ManagedColor

MAX_UPLOAD = 16 * 1024 * 1024
ID = re.compile(r'^[a-f0-9]{32}$')

class Store:
    def __init__(self, root: Path, owner='local'):
        self.root = root.resolve()
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.owner = hashlib.sha256(owner.encode()).hexdigest()
        self.home = self.root / self.owner
        for name in ('assets','jobs','tickets'):
            (self.home/name).mkdir(parents=True,exist_ok=True,mode=0o700)

    def path(self, area, ident):
        if area not in ('assets','jobs','tickets') or not ID.fullmatch(ident):
            raise ValueError('Invalid opaque asset/job identifier')
        return self.home/area/ident

    def put_asset(self, data: bytes, kind: str, filename='asset', provenance='original'):
        if not data or len(data)>MAX_UPLOAD:
            raise ValueError('Asset must be nonempty and at most 16 MiB')
        if kind == 'image':
            with Image.open(BytesIO(data)) as im:
                if im.width*im.height > 16_000_000 or im.format not in ('PNG','JPEG','TIFF','WEBP'):
                    raise ValueError('Supported assets: PNG/JPEG/TIFF/WebP up to 16 megapixels')
                im.verify()
        elif kind == 'font':
            with TTFont(BytesIO(data)) as f:
                if 'cmap' not in f: raise ValueError('Font has no cmap')
        elif kind == 'icc':
            ManagedColor(data)
        else:
            raise ValueError('Asset kind must be image, font, or icc')
        if provenance not in ('original','generated','extracted','reconstructed'):
            raise ValueError('Invalid provenance')
        ident = secrets.token_hex(16)
        path = self.path('assets',ident)
        path.mkdir(mode=0o700)
        (path/'original.bin').write_bytes(data)
        metadata=dict(asset_id=ident,kind=kind,filename=Path(filename).name[:160],
                      sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),provenance=provenance)
        (path/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False))
        return metadata

    def asset(self, ident, kind=None):
        path=self.path('assets',ident)
        meta=json.loads((path/'metadata.json').read_text())
        if kind and meta['kind'] != kind: raise ValueError(f'Expected {kind} asset')
        return path/'original.bin', meta

    def new_job(self):
        ident=secrets.token_hex(16)
        path=self.path('jobs',ident)
        path.mkdir(mode=0o700)
        return ident,path

    def mint(self, payload: dict, lifetime=900):
        ident=secrets.token_hex(16)
        # Capability material never goes into design/export files.
        token=secrets.token_urlsafe(32)
        record=dict(payload=payload,owner=self.owner,expires=time.time()+lifetime,
                    digest=hashlib.sha256(token.encode()).hexdigest())
        (self.path('tickets',ident)).write_text(json.dumps(record))
        return self.owner+'.'+ident+'.'+token

    @classmethod
    def resolve_ticket(cls,root: Path, ticket: str, purpose: str, consume=False):
        try:
            owner,ident,secret=ticket.split('.')
            if not re.fullmatch('[a-f0-9]{64}',owner) or not ID.fullmatch(ident):raise ValueError()
            path=root.resolve()/owner/'tickets'/ident
            record=json.loads(path.read_text())
            if record['expires']<time.time() or record['payload']['purpose']!=purpose:
                raise ValueError()
            if not hmac.compare_digest(record['digest'],hashlib.sha256(secret.encode()).hexdigest()):raise ValueError()
            if consume:
                # Atomic rename ensures a one-shot upload cannot be replayed concurrently.
                path.rename(path.with_suffix('.used'))
            instance=object.__new__(cls)
            instance.root=root.resolve();instance.owner=owner;instance.home=root.resolve()/owner
            return instance,record['payload']
        except (ValueError,FileNotFoundError,KeyError,json.JSONDecodeError):
            raise ValueError('Expired or invalid file capability') from None
