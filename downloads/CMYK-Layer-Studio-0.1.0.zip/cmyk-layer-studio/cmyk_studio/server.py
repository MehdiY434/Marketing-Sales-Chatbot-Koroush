"""Streamable HTTP MCP plus scoped binary transfer and Persian workbench."""
import asyncio
import base64
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit,unquote
import jwt
from mcp.server.fastmcp import FastMCP
from mcp.server.auth.provider import AccessToken
from mcp.server.auth.settings import AuthSettings
from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from starlette.requests import Request
from starlette.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.routing import Route
from .storage import Store,MAX_UPLOAD
from .models import Design
from .pipeline import build,ARTIFACTS
from .render import extract

ROOT=Path(os.environ.get('CMYK_DATA_DIR','./.studio-data'))
BASE=os.environ.get('CMYK_PUBLIC_BASE_URL','http://127.0.0.1:8765').rstrip('/')
parsed=urlsplit(BASE)
if parsed.scheme not in ('http','https') or parsed.path or parsed.query or parsed.fragment or parsed.username or not parsed.hostname:
    raise RuntimeError('CMYK_PUBLIC_BASE_URL must be an origin without path or credentials')
REMOTE=parsed.hostname not in ('127.0.0.1','localhost','::1')
ISSUER=os.environ.get('CMYK_OAUTH_ISSUER')
AUDIENCE=os.environ.get('CMYK_OAUTH_AUDIENCE',BASE+'/mcp')
JWKS=os.environ.get('CMYK_OAUTH_JWKS_URL')
if REMOTE and (parsed.scheme!='https' or not ISSUER or not JWKS):
    raise RuntimeError('Public hosting requires HTTPS and OAuth issuer/JWKS. Anonymous public mode is intentionally unsupported.')
if bool(ISSUER)!=bool(JWKS):raise RuntimeError('Configure both OAuth issuer and JWKS URL')
if ISSUER and (not ISSUER.startswith('https://') or not JWKS.startswith('https://')):
    raise RuntimeError('OAuth issuer and JWKS must use HTTPS')

class JWTVerifier:
    def __init__(self):
        self.keys=jwt.PyJWKClient(JWKS,cache_keys=True,timeout=10)
    async def verify_token(self,token):
        try:
            key=await asyncio.to_thread(self.keys.get_signing_key_from_jwt,token)
            claims=jwt.decode(token,key.key,algorithms=['RS256'],audience=AUDIENCE,issuer=ISSUER,
                              options={'require':['exp','iss','aud','sub']})
            if not claims['sub']:return None
            return AccessToken(token=token,client_id=str(claims.get('client_id',claims.get('azp','chatgpt'))),
                               scopes=str(claims.get('scope','')).split(),expires_at=int(claims['exp']),
                               resource=AUDIENCE,subject=claims['sub'])
        except (jwt.PyJWTError,ValueError,TypeError):return None

WORKFLOW=Path(__file__).with_name('workflow.md').read_text(encoding='utf-8')
security=TransportSecuritySettings(enable_dns_rebinding_protection=True,
    allowed_hosts=list(dict.fromkeys([parsed.netloc,'127.0.0.1:*','localhost:*','[::1]:*'])),
    allowed_origins=[BASE])
mcp=FastMCP('CMYK Layer Studio',instructions=WORKFLOW,stateless_http=True,json_response=True,
            max_request_body_size=24*1024*1024,transport_security=security,
            auth=AuthSettings(issuer_url=ISSUER,resource_server_url=BASE+'/mcp',required_scopes=['studio']) if ISSUER else None,
            token_verifier=JWTVerifier() if ISSUER else None)
CPU=asyncio.Semaphore(1)
READ=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False)
WRITE=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False)


def current_store():
    token=get_access_token()
    if ISSUER and not token:raise ValueError('Authenticated identity is required')
    return Store(ROOT, (ISSUER+'|'+token.subject) if token else 'local')


def result_with_links(store,report):
    files={}
    for fname in (*report.get('files',{}),'report.json','delivery.zip'):
        if (store.path('jobs',report['job_id'])/fname).is_file():
            ticket=store.mint(dict(purpose='download',job_id=report['job_id'],filename=fname),3600)
            files[fname]=BASE+'/download/'+ticket
    return dict(status=report['status'],job_id=report['job_id'],summary={k:report[k] for k in ('width','height','layer_count','profile','warnings','error','fallback') if k in report},
                files=files,preview_label='پیش‌نمایش RGB' if report['status']=='passed' else None,
                links_expire_in_seconds=3600)

@mcp.tool(annotations=READ)
def studio_capabilities() -> dict[str, Any]:
    """Check actual engine/validation support before planning a design."""
    from PIL import features
    return dict(psd='real PSD v1, 8-bit CMYK normal raster layers with per-layer alpha and Unicode names',
                icc='LittleCMS; selected output ICC embedded byte-for-byte in PSD/TIFF',
                text='Persian/RTL/mixed bidi via RAQM; raster layers only',raqm=features.check('raqm'),
                generation='No server-side image model or Photoshop access. Host-generated PNGs require explicit binary upload; procedural graphics/text work locally.',
                assets='16 MiB each; PNG/JPEG/TIFF/WebP, TTF/OTF, CMYK output ICC',
                limits=dict(canvas_megapixels=16,total_layer_megapixels=48,layers=24),
                unsupported=['native Photoshop text','Smart Objects','native layer masks/effects','automatic flat-image original-layer recovery','PSB','Photoshop UI testing'])

@mcp.tool(annotations=READ)
def plan_design(brief: str, width: int = 1200, height: int = 1500, dpi: int = 300) -> dict[str, Any]:
    """Create a meaningful layer plan before generating assets. Reuse conversation facts; this is a template, not an image generation call."""
    if not brief or len(brief)>8000 or not 64<=width<=6000 or not 64<=height<=6000 or width*height>16_000_000:
        raise ValueError('Provide a brief and supported canvas dimensions')
    return dict(brief=brief,canvas=dict(width=width,height=height,dpi=dpi),
                stacking_order='bottom to top',
                plan=[dict(role='background',method='procedural or separately generated full-canvas background; no baked-in subject/text'),
                      dict(role='effect',method='optional independent contact shadow; match lighting'),
                      dict(role='subject',method='separately uploaded/generated real-alpha PNG; preserve product identity'),
                      dict(role='decoration',method='optional individual transparent components with matching perspective/style'),
                      dict(role='logo',method='preserve uploaded original; place independently'),
                      dict(role='text',method='render final verified text with supplied font using RAQM; separate raster layer per text block')],
                transfer='create_upload_ticket -> binary PUT of host file -> asset_id, or upload_asset_base64; do not send host paths to the remote server',
                print='Prefer supplied printer ICC; otherwise ask only missing material print details, disclose explicit profile assumptions and no printer approval.')

@mcp.tool(annotations=WRITE)
def create_upload_ticket(kind: str, filename: str, provenance: str = 'original') -> dict[str, Any]:
    """Get a one-use, 15-minute binary upload URL. PUT actual file bytes; never assume host files exist on this server."""
    if kind not in ('image','font','icc'):raise ValueError('Unknown asset kind')
    if provenance not in ('original','generated','extracted','reconstructed'):raise ValueError('Unknown provenance')
    store=current_store()
    token=store.mint(dict(purpose='upload',kind=kind,filename=Path(filename).name,provenance=provenance))
    return dict(method='PUT',url=BASE+'/upload/'+token,content_type='application/octet-stream',max_bytes=MAX_UPLOAD,
                expires_in_seconds=900,response='JSON asset_id and original SHA256',browser_alternative='Use open_studio to upload with a file picker')

@mcp.tool(annotations=WRITE)
def upload_asset_base64(data_base64: str, kind: str, filename: str, provenance: str = 'original') -> dict[str, Any]:
    """Upload a small actual asset as base64; prefer binary PUT for large host-generated images."""
    if len(data_base64)>4*((MAX_UPLOAD+2)//3):raise ValueError('Asset exceeds size limit')
    return current_store().put_asset(base64.b64decode(data_base64,validate=True),kind,filename,provenance)

@mcp.tool(annotations=WRITE)
def extract_component(image_asset_id: str, mask_asset_id: str) -> dict[str, Any]:
    """Extract a flat-image component using an explicit same-sized grayscale mask. White retains; hidden pixels are not recovered."""
    return extract(current_store(),image_asset_id,mask_asset_id)

@mcp.tool(annotations=WRITE)
async def render_design(design: Design) -> dict[str, Any]:
    """Build actual CMYK layered PSD + CMYK TIFF + sRGB preview, independently validate, and return expiring download links. Never claim success if status is failed."""
    store=current_store()
    async with CPU:report,_=await asyncio.to_thread(build,design,store)
    return result_with_links(store,report)

@mcp.tool(annotations=READ)
def get_delivery(job_id: str) -> dict[str, Any]:
    """Read the actual job status and renew scoped artifact download links."""
    store=current_store()
    report=json.loads((store.path('jobs',job_id)/'report.json').read_text())
    return result_with_links(store,report)

@mcp.tool(annotations=READ)
def validate_output(job_id: str) -> dict[str, Any]:
    """Reopen the delivered files and repeat structure, CMYK/ICC, recomposition, hide/move/replace and sibling checks."""
    from psd_tools import PSDImage
    from psd_tools.constants import Resource
    from .validate import validate_psd,validate_deliverables
    store=current_store();path=store.path('jobs',job_id)
    report=json.loads((path/'report.json').read_text())
    if report['status']!='passed':return dict(status='failed',error=report.get('error'))
    for filename,record in report['files'].items():
        if __import__('hashlib').sha256((path/filename).read_bytes()).hexdigest()!=record['sha256']:
            raise ValueError('Artifact differs from recorded validated output: '+filename)
    design=Design.model_validate_json((path/'design.json').read_text())
    icc=PSDImage.open(path/'design.psd').image_resources.get_data(Resource.ICC_PROFILE)
    if __import__('hashlib').sha256(icc).hexdigest()!=report['profile']['sha256']:
        raise ValueError('Profile differs from recorded output')
    check,_=validate_psd(path/'design.psd',design,icc)
    check['siblings']=validate_deliverables(path/'design.psd',path/'design-cmyk.tiff',path/'preview-srgb.png',icc,design)
    return check

@mcp.tool(annotations=WRITE)
def open_studio(design: Design | None = None) -> dict[str, Any]:
    """Open the optional Persian RTL workbench for file uploads, layout JSON, print settings, preview and download."""
    token=current_store().mint(dict(purpose='studio',design=design.model_dump() if design else None),3600)
    return dict(url=BASE+'/studio/'+token,expires_in_seconds=3600,notice='Private scoped session URL; do not share. No provider keys belong in this interface.')

@mcp.prompt()
def cmyk_workflow() -> str:
    """The end-to-end planning, host asset handoff, color and validation workflow."""
    return WORKFLOW

async def upload(request: Request):
    try:
        store,payload=Store.resolve_ticket(ROOT,request.path_params['ticket'],'upload',consume=True)
        data=bytearray()
        async for chunk in request.stream():
            data.extend(chunk)
            if len(data)>MAX_UPLOAD:raise ValueError('Upload exceeds 16 MiB')
        result=await asyncio.to_thread(store.put_asset,bytes(data),payload['kind'],payload['filename'],payload['provenance'])
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except (ValueError,OSError) as e:return JSONResponse({'error':str(e)},status_code=400)

async def download(request: Request):
    try:
        store,payload=Store.resolve_ticket(ROOT,request.path_params['ticket'],'download')
        if payload['filename'] not in ARTIFACTS:raise ValueError('Unknown deliverable')
        path=store.path('jobs',payload['job_id'])/payload['filename']
        if not path.is_file():raise ValueError('Missing deliverable')
        return FileResponse(path,filename=payload['filename'],headers={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'})
    except (ValueError,OSError) as e:return JSONResponse({'error':str(e)},status_code=404)

async def studio(request: Request):
    try:
        store,payload=Store.resolve_ticket(ROOT,request.path_params['ticket'],'studio')
        action=request.path_params.get('action')
        if request.method=='GET' and not action:
            if request.query_params.get('config')=='1':return JSONResponse({'design':payload.get('design')},headers={'Cache-Control':'no-store'})
            return HTMLResponse(Path(__file__).with_name('static').joinpath('studio.html').read_text(),headers={
                'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
                'Content-Security-Policy':"default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"})
        if action=='assets':
            data=bytearray()
            async for chunk in request.stream():
                data.extend(chunk)
                if len(data)>MAX_UPLOAD:raise ValueError('Upload exceeds 16 MiB')
            result=await asyncio.to_thread(store.put_asset,bytes(data),request.query_params.get('kind','image'),unquote(request.headers.get('X-Filename','asset')))
            return JSONResponse(result)
        if action=='render':
            data=bytearray()
            async for chunk in request.stream():
                data.extend(chunk)
                if len(data)>128*1024:raise ValueError('Design manifest too large')
            design=Design.model_validate_json(bytes(data))
            async with CPU:report,_=await asyncio.to_thread(build,design,store)
            return JSONResponse(result_with_links(store,report))
        return JSONResponse({'error':'Unknown action'},status_code=404)
    except (ValueError,OSError) as e:return JSONResponse({'error':str(e)},status_code=400)

async def health(request):return JSONResponse({'service':'CMYK Layer Studio','status':'ok','authentication':'oauth' if ISSUER else 'loopback-only'})

app=mcp.streamable_http_app()
app.routes.extend([Route('/health',health),Route('/upload/{ticket}',upload,methods=['PUT']),
                   Route('/download/{ticket}',download),Route('/studio/{ticket}',studio),
                   Route('/studio/{ticket}/{action}',studio,methods=['POST'])])
