"""Read files through independent psd-tools, never through the PSD writer."""
from copy import copy
from hashlib import sha256
from io import BytesIO
import numpy as np
from PIL import Image, ImageCms
from psd_tools import PSDImage
from psd_tools.constants import ColorMode, Resource, ChannelID
from .color import ManagedColor, SRGB


def _compose_readback(layers,size,omit=None,move=None,replacement=None):
    # Independent array implementation, in CMYK document space with normal alpha.
    w,h=size
    out=np.zeros((h,w,4),dtype=np.uint8)
    for i,l in enumerate(layers):
        if i==omit or not l.visible:continue
        image=l.topil(apply_icc=False)
        if image is None:raise ValueError('Reader found a layer without pixels')
        ink=np.asarray(image,dtype=np.uint32)
        alpha=l.topil(ChannelID.TRANSPARENCY_MASK,apply_icc=False)
        if alpha is None:raise ValueError('Layer has no independent alpha channel')
        a=np.asarray(alpha,dtype=np.uint32)[...,None]
        if replacement==i:
            ink=np.broadcast_to([255,0,255,0],ink.shape).astype(np.uint32)
        x,y=l.left,l.top
        if move and move[0]==i:x+=move[1];y+=move[2]
        left,top=max(0,x),max(0,y)
        right,bottom=min(w,x+image.width),min(h,y+image.height)
        if right<=left or bottom<=top:continue
        part=out[top:bottom,left:right].astype(np.uint32)
        source=ink[top-y:bottom-y,left-x:right-x];mask=a[top-y:bottom-y,left-x:right-x]
        out[top:bottom,left:right]=((source*mask+part*(255-mask)+127)//255).astype(np.uint8)
    return out


def validate_psd(path,design,icc,expected_layers=None):
    psd=PSDImage.open(path)
    def require(condition,message):
        if not condition:raise ValueError('PSD validation failed: '+message)
    require(psd.color_mode==ColorMode.CMYK,'document is not CMYK')
    require(psd.depth==8,'expected 8-bit samples')
    require(psd.size==(design.width,design.height),'dimensions mismatch')
    embedded=psd.image_resources.get_data(Resource.ICC_PROFILE)
    require(embedded==icc,'ICC missing or not byte-identical to selected profile')
    ManagedColor(embedded)
    require(len(psd)==len(design.layers),'layer count mismatch')
    require([l.name for l in psd]==[l.name for l in design.layers],'name/order mismatch (bottom to top)')
    composite=psd.topil(apply_icc=False)
    require(composite is not None and composite.mode=='CMYK','missing CMYK merged image')
    independent=_compose_readback(psd,psd.size)
    require(np.array_equal(np.asarray(composite),independent),'merged image differs from independently recomposed layers')
    rows=[]
    for i,(layer,spec) in enumerate(zip(psd,design.layers)):
        alpha=layer.topil(ChannelID.TRANSPARENCY_MASK,apply_icc=False)
        pixels=layer.topil(apply_icc=False)
        require(alpha is not None and alpha.getbbox() is not None,'empty/missing alpha: '+layer.name)
        require(layer.is_visible(),'hidden output layer: '+layer.name)
        if expected_layers:
            original=expected_layers[i]
            require(layer.bbox==(original.x,original.y,original.x+original.ink.width,original.y+original.ink.height),'position mismatch')
            require(pixels.tobytes()==original.ink.tobytes(),'CMYK samples changed: '+layer.name)
            require(alpha.tobytes()==original.alpha.tobytes(),'transparency changed: '+layer.name)
        hidden=_compose_readback(psd,psd.size,omit=i)
        changed=int(np.count_nonzero(np.any(independent!=hidden,axis=-1)))
        if i==0:
            # Removing an opaque white background may expose transparency while
            # leaving CMYK ink values unchanged. Check coverage as well as ink.
            coverage=Image.new('L',psd.size,0)
            for foreground in list(psd)[1:]:
                fa=foreground.topil(ChannelID.TRANSPARENCY_MASK,apply_icc=False)
                coverage.paste(Image.new('L',fa.size,255),(foreground.left,foreground.top),fa)
            changed=max(changed,int(np.count_nonzero(np.asarray(coverage)<255)))
        require(changed>0,'empty/redundant/fully occluded layer: '+layer.name)
        row=dict(name=layer.name,role=spec.role,bounds=layer.bbox,alpha_extrema=alpha.getextrema(),
                 cmyk_sha256=sha256(pixels.tobytes()).hexdigest(),hide_changed_pixels=changed)
        if spec.role!='background':
            dx=max(3,min(31,design.width//12));dy=max(3,min(19,design.height//12))
            moved=_compose_readback(psd,psd.size,move=(i,dx,dy))
            diff=int(np.count_nonzero(np.any(moved!=independent,axis=-1)))
            require(diff>0,'moving layer has no effect: '+layer.name)
            replaced=_compose_readback(psd,psd.size,replacement=i)
            replace_diff=int(np.count_nonzero(np.any(replaced!=independent,axis=-1)))
            require(replace_diff>0,'replacing layer has no effect: '+layer.name)
            row.update(move_test=dict(dx=dx,dy=dy,changed_pixels=diff),replace_changed_pixels=replace_diff)
        if spec.kind=='text':
            require(alpha.getextrema()[0]<255,'text lacks transparent surrounding pixels')
            row.update(text=spec.text,editability='raster',glyph_rendering='RAQM required during render; visual inspection also required')
        rows.append(row)
    return dict(status='passed',reader='psd-tools',photoshop_tested=False,
                checks=['PSD structure','CMYK mode','dimensions','ICC exact bytes','names/order/count',
                        'CMYK and alpha samples','independent composite versus merged pixels',
                        'hide every layer','move and replace every foreground layer'],
                layers=rows,profile_sha256=sha256(embedded).hexdigest()),composite


def validate_deliverables(psd_path,tiff_path,png_path,icc,design):
    final=PSDImage.open(psd_path).topil(apply_icc=False)
    with Image.open(tiff_path) as tiff:
        if tiff.mode!='CMYK' or tiff.info.get('icc_profile')!=icc or tiff.size!=final.size or tiff.tobytes()!=final.tobytes():
            raise ValueError('TIFF mode, ICC, dimensions or composite differs from final PSD')
        dpi=tiff.info.get('dpi')
        if not dpi or abs(dpi[0]-design.dpi)>.01:raise ValueError('TIFF resolution mismatch')
    manager=ManagedColor(icc,design.rendering_intent)
    with Image.open(png_path) as preview:
        expected=manager.to_rgb(final)
        if preview.mode!='RGB' or preview.size!=final.size or preview.tobytes()!=expected.tobytes():
            raise ValueError('RGB preview was not derived from final PSD composite')
        if not preview.info.get('icc_profile') or preview.info.get('Description')!='پیش‌نمایش RGB':
            raise ValueError('PNG needs embedded sRGB and RGB preview label')
        profile=ImageCms.getOpenProfile(BytesIO(preview.info['icc_profile']))
        if profile.profile.xcolor_space.strip()!='RGB':
            raise ValueError('Preview ICC is not an RGB profile')
        # Verify the declared profile actually behaves as sRGB, without relying
        # on its name or creation timestamp, which changes between processes.
        probes=np.array([(r,g,b) for r in (0,32,96,160,224,255)
                         for g in (0,32,96,160,224,255)
                         for b in (0,32,96,160,224,255)],dtype=np.uint8).reshape(18,12,3)
        mapped=ImageCms.profileToProfile(Image.fromarray(probes),profile,SRGB,outputMode='RGB')
        if np.abs(np.asarray(mapped,dtype=np.int16)-probes.astype(np.int16)).max()>1:
            raise ValueError('Preview ICC does not behave as sRGB')
    return dict(status='passed',tiff='CMYK; same profile and exact merged pixels',png='sRGB; derived from reopened final PSD',label='پیش‌نمایش RGB')
