import json
import shutil
import subprocess
from io import BytesIO
import pytest
import numpy as np
from PIL import Image
from psd_tools import PSDImage
from psd_tools.constants import ColorMode,Resource,ChannelID
from cmyk_studio.pipeline import build
from cmyk_studio.color import DEFAULT_PROFILE,SRGB_BYTES,ManagedColor
from cmyk_studio.validate import validate_psd,validate_deliverables,_compose_readback
from cmyk_studio.render import extract


def test_end_to_end_files_and_independent_channels(store,design):
    report,path=build(design,store)
    assert report['status']=='passed',report
    assert report['photoshop_tested'] is False
    psd=PSDImage.open(path/'design.psd')
    assert psd.color_mode==ColorMode.CMYK and len(psd)==4
    assert psd.image_resources.get_data(Resource.ICC_PROFILE)==DEFAULT_PROFILE.read_bytes()
    assert psd[1].name=='سوژه مستقل 🌿'
    alpha=psd[1].topil(ChannelID.TRANSPARENCY_MASK)
    assert alpha.getextrema()==(0,255) and 150 in alpha.getdata()
    assert all(r['hide_changed_pixels']>0 for r in report['validation']['layers'])
    assert all(r['move_test']['changed_pixels']>0 and r['replace_changed_pixels']>0 for r in report['validation']['layers'][1:])
    assert report['deliverable_validation']['status']=='passed'
    import zipfile
    with zipfile.ZipFile(path/'delivery.zip') as z:
        assert {'design.psd','design-cmyk.tiff','preview-srgb.png','report.json'}<=set(z.namelist())
    # Original provided fonts and logo/subject bytes remain unchanged in asset storage.
    for row in report['layers']:
        if row.get('source_asset_id'):
            import hashlib
            original,meta=store.asset(row['source_asset_id'])
            assert hashlib.sha256(original.read_bytes()).hexdigest()==row['asset_sha256']


def test_real_hide_move_resave_and_reopen(store,design,tmp_path):
    report,path=build(design,store);assert report['status']=='passed'
    psd=PSDImage.open(path/'design.psd');original=_compose_readback(psd,psd.size)
    psd[1].visible=False
    variant=tmp_path/'hidden.psd';psd.save(variant)
    read=PSDImage.open(variant)
    assert read[1].visible is False
    assert np.any(_compose_readback(read,read.size)!=original)
    psd=PSDImage.open(path/'design.psd');psd[1].offset=(psd[1].left+17,psd[1].top+11)
    variant=tmp_path/'moved.psd';psd.save(variant)
    read=PSDImage.open(variant)
    assert read[1].offset==psd[1].offset
    assert np.any(_compose_readback(read,read.size)!=original)


def test_second_decoder_imagemagick(store,design,tmp_path):
    if not shutil.which('magick'):pytest.skip('Optional ImageMagick cross-reader not installed')
    report,path=build(design,store);assert report['status']=='passed'
    result=subprocess.run(['magick','identify','-format','%[colorspace] %n\n',str(path/'design.psd')],capture_output=True,text=True,check=True)
    assert 'CMYK 5' in result.stdout
    raw=tmp_path/'readback.cmyk'
    subprocess.run(['magick',str(path/'design.psd')+'[0]','-depth','8','CMYK:'+str(raw)],check=True,capture_output=True)
    assert raw.read_bytes()==PSDImage.open(path/'design.psd').topil(apply_icc=False).tobytes()


def test_tampered_merged_pixels_rejected(store,design):
    report,path=build(design,store);assert report['status']=='passed'
    psd=path/'design.psd';data=bytearray(psd.read_bytes());data[-1]^=255;psd.write_bytes(data)
    with pytest.raises(ValueError,match='merged image differs'):
        validate_psd(psd,design,DEFAULT_PROFILE.read_bytes())


def test_rgb_psd_and_wrong_icc_rejected(store,design,tmp_path):
    rgb=tmp_path/'rgb.psd';PSDImage.new('RGB',(256,320)).save(rgb)
    with pytest.raises(ValueError,match='not CMYK'):validate_psd(rgb,design,DEFAULT_PROFILE.read_bytes())
    with pytest.raises(ValueError,match='CMYK device space'):ManagedColor(SRGB_BYTES)
    report,path=build(design,store);assert report['status']=='passed'
    with pytest.raises(ValueError,match='ICC missing'):validate_psd(path/'design.psd',design,SRGB_BYTES)


def test_empty_duplicate_occluded_and_overflow_fail_honestly(store,design):
    # Duplicate layers cannot satisfy multilayer acceptance.
    duplicate=design.model_copy(deep=True)
    duplicate.layers.append(duplicate.layers[-1].model_copy(update={'name':'تکرار'}))
    report,path=build(duplicate,store)
    assert report['status']=='failed' and 'Duplicate' in report['error']
    assert not (path/'design.psd').exists()
    outside=design.model_copy(deep=True);outside.layers[1].x=2000
    report,path=build(outside,store);assert report['status']=='failed' and 'outside canvas' in report['error']
    oversized=design.model_copy(deep=True);oversized.layers[-1].font_size=150
    report,path=build(oversized,store);assert report['status']=='failed' and 'does not fit' in report['error']
    covered=design.model_copy(deep=True)
    covered.layers.append(covered.layers[0].model_copy(update={'name':'پوشش کامل','role':'decoration','kind':'solid','color':'#112233'}))
    report,path=build(covered,store)
    assert report['status']=='failed' and 'occluded' in report['error'] and (path/'components.zip').is_file()
    assert not (path/'design.psd').exists()


def test_white_background_transparency_is_meaningful(store,design):
    design.layers[0].kind='solid';design.layers[0].color='#ffffff'
    report,_=build(design,store)
    assert report['status']=='passed',report


def test_reject_missing_glyph_and_untagged_cmyk(store,design):
    design.layers[-1].text='𒀀'
    report,_=build(design,store);assert report['status']=='failed' and 'glyph' in report['error']
    im=Image.new('CMYK',(10,10));b=BytesIO();im.save(b,'TIFF')
    asset=store.put_asset(b.getvalue(),'image','no-profile.tiff')
    design.layers[-1].text='سلام';design.layers[1].asset_id=asset['asset_id']
    report,_=build(design,store);assert report['status']=='failed' and 'embedded ICC' in report['error']


def test_flat_mask_extraction_requires_actual_mask(store):
    im=Image.new('RGB',(40,40),'red');mask=Image.new('L',(40,40),0);mask.paste(180,(10,8,30,32))
    def asset(image):
        b=BytesIO();image.save(b,'PNG');return store.put_asset(b.getvalue(),'image')['asset_id']
    result=extract(store,asset(im),asset(mask))
    assert result['source_bounds']==(10,8,30,32) and result['provenance']=='extracted'
    path,_=store.asset(result['asset_id'])
    with Image.open(path) as img:assert img.mode=='RGBA' and img.getchannel('A').getextrema()==(180,180)


def test_preview_icc_is_checked_not_just_its_label(store,design):
    report,path=build(design,store);assert report['status']=='passed'
    png=path/'preview-srgb.png'
    from PIL import PngImagePlugin
    with Image.open(png) as original:im=original.copy()
    meta=PngImagePlugin.PngInfo();meta.add_text('Description','پیش‌نمایش RGB')
    im.save(png,icc_profile=DEFAULT_PROFILE.read_bytes(),pnginfo=meta)
    with pytest.raises(ValueError,match='not an RGB profile'):
        validate_deliverables(path/'design.psd',path/'design-cmyk.tiff',png,DEFAULT_PROFILE.read_bytes(),design)


def test_supplied_printer_profile_wins_even_without_a_default(store,design,monkeypatch,tmp_path):
    from cmyk_studio import pipeline
    profile=store.put_asset(DEFAULT_PROFILE.read_bytes(),'icc','printer-output.icc')
    design.profile_id=profile['asset_id']
    monkeypatch.setattr(pipeline,'DEFAULT_PROFILE',tmp_path/'missing-default.icc')
    report,path=build(design,store)
    assert report['status']=='passed',report
    assert report['profile_source']=='user'
    assert PSDImage.open(path/'design.psd').image_resources.get_data(Resource.ICC_PROFILE)==DEFAULT_PROFILE.read_bytes()
    assert report['printer_approved'] is False
