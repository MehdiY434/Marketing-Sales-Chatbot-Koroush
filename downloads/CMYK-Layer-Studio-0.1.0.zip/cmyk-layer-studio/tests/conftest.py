from io import BytesIO
from pathlib import Path
import pytest
from PIL import Image,ImageDraw
from cmyk_studio.storage import Store
from cmyk_studio.models import Design
from cmyk_studio.render import DEFAULT_FONT

@pytest.fixture
def store(tmp_path):return Store(tmp_path/'data')

@pytest.fixture
def design(store):
    im=Image.new('RGBA',(90,120))
    draw=ImageDraw.Draw(im);draw.rounded_rectangle((12,7,78,113),radius=14,fill=(205,116,25,255));draw.ellipse((4,35,50,85),fill=(55,140,70,150))
    blob=BytesIO();im.save(blob,'PNG')
    image=store.put_asset(blob.getvalue(),'image','subject.png','generated')
    font=store.put_asset(DEFAULT_FONT.read_bytes(),'font','font.ttf')
    return Design.model_validate(dict(title='آزمون',width=256,height=320,layers=[
        dict(name='پس‌زمینه',role='background',kind='gradient',width=256,height=320,color='#eee5c8',color_end='#fffaf4'),
        dict(name='سوژه مستقل 🌿',role='subject',kind='image',asset_id=image['asset_id'],x=65,y=115,width=130,height=150),
        dict(name='لوگو',role='logo',kind='ellipse',color='#1c5533',x=205,y=12,width=30,height=30),
        dict(name='متن فارسی و لاتین',role='text',kind='text',text='زیبایی | CMYK 30',font_id=font['asset_id'],font_size=20,x=8,y=60,width=240,height=42,color='#1c5533')]))
