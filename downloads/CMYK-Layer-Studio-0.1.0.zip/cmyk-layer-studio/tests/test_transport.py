import asyncio
import base64
import json
import os
import subprocess
import sys
import time
from io import BytesIO
import pytest
from PIL import Image
from starlette.testclient import TestClient
from cmyk_studio.storage import Store


def test_ticket_expiry_tamper_replay_and_owner_isolation(tmp_path):
    store=Store(tmp_path/'data','alice')
    token=store.mint({'purpose':'upload'})
    with pytest.raises(ValueError):Store.resolve_ticket(store.root,token+'x','upload')
    with pytest.raises(ValueError):Store.resolve_ticket(store.root,token,'download')
    resolved,payload=Store.resolve_ticket(store.root,token,'upload',consume=True)
    assert resolved.owner==store.owner
    with pytest.raises(ValueError):Store.resolve_ticket(store.root,token,'upload',consume=True)
    expired=store.mint({'purpose':'download'},-1)
    with pytest.raises(ValueError):Store.resolve_ticket(store.root,expired,'download')
    with pytest.raises(ValueError):store.path('assets','../../etc/passwd')
    b=BytesIO();Image.new('RGB',(2,2)).save(b,'PNG')
    a=store.put_asset(b.getvalue(),'image')
    other=Store(store.root,'bob')
    with pytest.raises(FileNotFoundError):other.asset(a['asset_id'])


def test_public_server_requires_https_and_oauth(tmp_path):
    env=os.environ.copy();env['CMYK_PUBLIC_BASE_URL']='http://studio.example.com'
    env.pop('CMYK_OAUTH_ISSUER',None);env.pop('CMYK_OAUTH_JWKS_URL',None)
    p=subprocess.run([sys.executable,'-c','import cmyk_studio.server'],capture_output=True,text=True,env=env)
    assert p.returncode!=0 and 'Public hosting requires HTTPS' in p.stderr


def test_mcp_tools_binary_transfer_ui_and_download(tmp_path,monkeypatch,design,store):
    from cmyk_studio import server
    monkeypatch.setattr(server,'ROOT',store.root)
    with TestClient(server.app,base_url='http://127.0.0.1:8765') as client:
        headers={'Accept':'application/json, text/event-stream','Content-Type':'application/json'}
        def rpc(method,params,ident=1):
            r=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':ident,'method':method,'params':params})
            assert r.status_code==200,r.text
            data=r.json();assert 'error' not in data,data
            return data['result']
        init=rpc('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'acceptance','version':'1'}})
        assert init['serverInfo']['name']=='CMYK Layer Studio'
        listed=rpc('tools/list',{})
        assert {'render_design','validate_output','create_upload_ticket','open_studio'}<={x['name'] for x in listed['tools']}
        assert len(rpc('prompts/list',{})['prompts'])==1
        call=lambda name,args:rpc('tools/call',{'name':name,'arguments':args})
        ticket=call('create_upload_ticket',{'kind':'image','filename':'test.png'})['structuredContent']
        b=BytesIO();Image.new('RGBA',(20,20),(20,90,40,150)).save(b,'PNG')
        uploaded=client.put(ticket['url'],content=b.getvalue())
        assert uploaded.status_code==200 and uploaded.json()['sha256']
        assert client.put(ticket['url'],content=b.getvalue()).status_code==400
        # Existing local owner assets are the same scope used by local MCP.
        rendered=call('render_design',{'design':design.model_dump()})
        assert not rendered.get('isError'),rendered
        result=rendered['structuredContent'];assert result['status']=='passed',result
        psd=client.get(result['files']['design.psd']);assert psd.content[:4]==b'8BPS'
        assert client.get(result['files']['preview-srgb.png']).content[:8]==b'\x89PNG\r\n\x1a\n'
        check=call('validate_output',{'job_id':result['job_id']})['structuredContent']
        assert check['status']=='passed' and check['siblings']['status']=='passed'
        ui=call('open_studio',{'design':design.model_dump()})['structuredContent']['url']
        page=client.get(ui);assert 'dir="rtl"' in page.text and 'پیش‌نمایش RGB' in page.text
        assert client.get(ui+'?config=1').json()['design']['brief']==design.brief
        assert client.get('/download/not-a-ticket').status_code==404
        assert client.post(ui+'/render',content=b'x'*131073).status_code==400
        # No unsafe file-path or arbitrary URL import tool is exposed.
        for tool in listed['tools']:
            if tool['name'].startswith('upload'):assert 'path' not in tool['inputSchema']['properties']


def test_oauth_signature_audience_expiry_and_subject(monkeypatch):
    from types import SimpleNamespace
    import jwt
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cmyk_studio import server
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    monkeypatch.setattr(server,'ISSUER','https://issuer.example/')
    monkeypatch.setattr(server,'AUDIENCE','https://studio.example/mcp')
    verifier=object.__new__(server.JWTVerifier)
    verifier.keys=SimpleNamespace(get_signing_key_from_jwt=lambda token:SimpleNamespace(key=key.public_key()))
    claims=dict(iss='https://issuer.example/',aud='https://studio.example/mcp',sub='alice',exp=int(time.time())+120,scope='studio')
    encode=lambda c:jwt.encode(c,key,algorithm='RS256')
    valid=asyncio.run(verifier.verify_token(encode(claims)))
    assert valid.subject=='alice' and valid.scopes==['studio']
    for bad in ({**claims,'aud':'https://wrong.example'},{**claims,'exp':1},{**claims,'sub':''}):
        assert asyncio.run(verifier.verify_token(encode(bad))) is None
    attacker=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    assert asyncio.run(verifier.verify_token(jwt.encode(claims,attacker,algorithm='RS256'))) is None
