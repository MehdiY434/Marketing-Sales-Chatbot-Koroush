# Third-party components

Project code is MIT. Dependencies remain under their upstream licenses; the project license does not replace them. Pinned packages and integrity hashes are in requirements.lock.

- Pillow (HPND), LittleCMS (MIT), RAQM (MIT), HarfBuzz (MIT), FriBidi (LGPL): image I/O, ICC, shaping/bidi; binary wheels may include these libraries. See Pillow's bundled license notices.
- numpy (BSD), psd-tools (MIT), fonttools (MIT), MCP Python SDK (MIT), Uvicorn (BSD), PyJWT (MIT), cryptography (Apache/BSD): see each installed distribution's notices, including transitive packages.
- Ghostscript / Artifex default CMYK ICC comes from the operating system package. This project does not redistribute a standalone copy in its source/wheel. CMYK outputs embed the selected profile as required. The system package's license notices cover its profiles (in this build, Debian ghostscript lists iccprofiles under AGPL-3+; retain upstream notices when redistributing that system package or container). The Dockerfile installs the unmodified Debian package; upstream source is available via Debian and https://github.com/ArtifexSoftware/ghostpdl . User-supplied ICC profiles remain subject to their own terms.
- DejaVu Sans is a system fallback/demo font (Bitstream Vera / DejaVu terms). It is used to render pixels; no font program is embedded into PSD. Supplied original fonts remain in the private server asset store and are not included in delivery bundles.
- ImageMagick (ImageMagick license) is an optional independent cross-reader used in tests; not required by the runtime wheel.
- Bundled demo-subject.png was generated through the host image-generation tool for the acceptance sample. No user logo or proprietary brand font was used. The demonstration logo is original procedural artwork.
